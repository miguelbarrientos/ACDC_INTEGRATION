# ACDC Integration Skill

A subject-matter-expert skill for integrating PayPal **Advanced Credit and Debit Card (ACDC)** payments end-to-end. Designed to help any developer (junior to senior) implement, debug, or extend an ACDC checkout — covering OAuth2, Card Fields, Orders v2, Vault, MSI/IC2B installments, 3DS Risk Initiated, Fraudnet, and STC.

## What's inside

```
acdc-integration-skill/
├── SKILL.md                                  ← Skill manifest + agent guidance
├── README.md                                 ← This file
├── references/
│   ├── 01-architecture.md
│   ├── 02-oauth-and-tokens.md
│   ├── 03-card-fields-frontend.md
│   ├── 04-orders-and-capture.md
│   ├── 05-installments-msi-ic2b.md
│   ├── 06-vault-tokenization.md
│   ├── 07-3ds-risk-initiated.md
│   ├── 08-fraudnet-and-stc.md
│   ├── 09-sandbox-testing.md
│   ├── 10-troubleshooting.md
│   └── 11-pre-production-checklist.md
└── examples/
    ├── server.js                             ← Full Node/Express reference
    ├── index.html                            ← Card Fields HTML
    ├── app.js                                ← Frontend with CMID/Fraudnet/SDK
    └── curl-recipes.md                       ← cURL for every PayPal endpoint used
```

## How to install (Claude Code / Cowork)

1. Copy the entire `acdc-integration-skill/` folder into your skills directory:
   - **Cowork / Claude Code:** `~/.claude/skills/acdc-integration/`
   - **Project-specific:** `<your-project>/.claude/skills/acdc-integration/`
2. Restart your client (or run `/skills reload` if your client supports it).
3. The skill's description triggers automatically on ACDC-related questions in English or Spanish — no manual invocation required.

## How to share with teammates

- Zip the entire folder (`acdc-integration-skill.zip`) and send it.
- Recipients unzip into the path shown above.

## What this skill never does

- It never includes real card numbers, CVVs, expiry dates, account IDs, or secrets.
- It never references a specific internal repository, project, or codebase.
- All examples use `{{PLACEHOLDERS}}` and `process.env.*` references; production data must come from the developer's own systems.

## Authoritative external sources

The skill complements PayPal's official documentation. When in doubt, defer to:

- Orders v2 — `https://developer.paypal.com/docs/api/orders/v2/`
- Vault v3 — `https://developer.paypal.com/docs/api/payment-tokens/v3/`
- Card testing — `https://developer.paypal.com/tools/sandbox/card-testing/`
- JS SDK reference — `https://developer.paypal.com/sdk/js/reference/`
- Set Transaction Context (STC) — request from your PayPal Integration Engineer

## Versioning

- v1.0 — Initial release. Covers ACDC + Card Fields + Vault + MSI/IC2B + 3DS Risk Initiated + Fraudnet + STC. Mexico-focused (MXN, locale es-MX) with notes for adaptation.
