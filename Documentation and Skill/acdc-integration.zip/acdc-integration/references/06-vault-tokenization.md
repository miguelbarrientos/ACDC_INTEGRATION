# 06 — Vault: Tokenize, List, Charge, Delete

## What Vault gives you

A **payment method token** is an opaque string PayPal returns instead of the real card data. You can use it later to charge the same buyer without showing card fields again. The merchant **never** holds PAN/CVV — you store only the token ID and (optionally) the display metadata PayPal returns alongside (`brand`, `last_digits`, `expiry`).

## Two ways to populate the Vault

| Method | When | How |
|--------|------|-----|
| **Vault-with-Purchase** (recommended) | First successful charge on a new card | Add `payment_source.card.attributes.vault` to your Create Order body. The card is saved only on `ON_SUCCESS`. |
| Vault-only (no charge) | Less common; saving a payment method ahead of time | Use the dedicated Vault Setup Token + Payment Token flow (out of scope here). |

## Customer ID — the link between buyer and tokens

Every token belongs to a `customer.id`. **This must be your stable internal user ID** (not an email, not a session ID). Same customer must use the same ID across visits, otherwise tokens won't be retrievable.

```
customer.id = "{{INTERNAL_USER_ID}}"   // e.g. UUID, integer, etc. — your DB primary key
```

Treat the customer ID as PII-adjacent; don't use raw email or other identifiers that change.

## Saving a card during checkout (Vault-with-Purchase)

Add to the Create Order payload from `references/04-orders-and-capture.md`:

```json
"payment_source": {
  "card": {
    "attributes": {
      "customer": { "id": "{{INTERNAL_USER_ID}}" },
      "vault": {
        "store_in_vault": "ON_SUCCESS",
        "usage_type": "MERCHANT",
        "customer_type": "CONSUMER",
        "permit_multiple_payment_tokens": true
      }
    }
  }
}
```

Field reference:

| Field | Meaning |
|-------|---------|
| `customer.id` | Your internal user ID. Required to associate tokens with the buyer. |
| `vault.store_in_vault` | `ON_SUCCESS` saves only on completed transactions. `ALWAYS` (rarely used) saves regardless. |
| `vault.usage_type` | `MERCHANT` for merchant-initiated future charges. `PLATFORM` for marketplace platforms. |
| `vault.customer_type` | `CONSUMER` (B2C) or `BUSINESS`. |
| `vault.permit_multiple_payment_tokens` | `true` lets the same buyer save multiple cards. |

## Listing saved cards for a buyer

Server proxy:

```js
app.get('/api/vault/payment-tokens', async (req, res) => {
  try {
    const { customer_id } = req.query;
    if (!customer_id) return res.status(400).json({ error: 'customer_id required' });

    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v3/vault/payment-tokens?customer_id=${encodeURIComponent(customer_id)}`,
      {
        method:  'GET',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    res.status(r.status).json(await r.json());
  } catch (err) { res.status(500).json({ error: err.message }); }
});
```

Frontend:

```js
async function loadSavedCards(customerId) {
  const r = await fetch(`/api/vault/payment-tokens?customer_id=${encodeURIComponent(customerId)}`);
  const data = await r.json();
  return (data.payment_tokens || []).map(t => ({
    id:         t.id,
    brand:      t.payment_source?.card?.brand,
    last4:      t.payment_source?.card?.last_digits,
    expiry:     t.payment_source?.card?.expiry,        // "YYYY-MM"
    holder:     t.payment_source?.card?.name,
  }));
}
```

Sample response shape:

```json
{
  "customer": { "id": "{{INTERNAL_USER_ID}}" },
  "payment_tokens": [
    {
      "id": "{{PAYMENT_METHOD_TOKEN_ID}}",
      "payment_source": {
        "card": {
          "brand":       "VISA",
          "last_digits": "{{LAST_4}}",
          "expiry":      "{{YYYY-MM}}",
          "name":        "{{CARDHOLDER_NAME}}"
        }
      },
      "links": [
        { "rel": "self",   "href": "https://api-m.sandbox.paypal.com/v3/vault/payment-tokens/{{TOKEN_ID}}" },
        { "rel": "delete", "href": "https://api-m.sandbox.paypal.com/v3/vault/payment-tokens/{{TOKEN_ID}}" }
      ]
    }
  ]
}
```

## Charging with a saved token

Build the same Create Order payload as for a new card (`references/04-orders-and-capture.md`), but replace the `payment_source` block:

```json
"payment_source": {
  "token": {
    "id":   "{{PAYMENT_METHOD_TOKEN_ID}}",
    "type": "PAYMENT_METHOD_TOKEN"
  }
}
```

(Optional: add `attributes.installments` for IC2B/MSI — see `references/05-installments-msi-ic2b.md`.)

> **After Create Order with `payment_source.token`, always `GET /v2/checkout/orders/{id}` first.** PayPal may auto-capture in the same request, in which case the order status comes back as `COMPLETED` and you must not call capture again. If status is `APPROVED`, capture explicitly.

## Deleting a saved token

```js
app.delete('/api/vault/payment-tokens/:tokenId', async (req, res) => {
  try {
    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v3/vault/payment-tokens/${encodeURIComponent(req.params.tokenId)}`,
      {
        method:  'DELETE',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    if (r.status === 204) return res.status(204).send();
    res.status(r.status).json(await r.json());
  } catch (err) { res.status(500).json({ error: err.message }); }
});
```

PayPal returns `204 No Content` on successful delete.

## Pitfalls

| Pitfall | Why | Fix |
|---------|-----|-----|
| Tokens not appearing on second visit | Different `customer_id` was used at save time | Standardize on a single internal user ID across save and list calls. |
| Saved a card on a failed transaction | `store_in_vault: "ALWAYS"` | Use `"ON_SUCCESS"` unless you have a specific reason. |
| Token charge succeeds but capture is called twice | Auto-capture already completed | Always `GET /orders/:id`; capture only if status is `APPROVED`. |
| UI shows a wrong brand | Reading the wrong nested path | Use `payment_source.card.brand`, not just `brand` at the top level. |
| Token reuse across users | Cross-account leakage risk | Tokens are tied to one `customer.id`; always pass that customer ID when creating the order with the token. |
