# 11 — Pre-Production Checklist

Run through every box before flipping from sandbox to live.

## Security

- [ ] `CLIENT_SECRET` exists only in server environment variables. Not in any frontend bundle, not in source control, not in client-side configuration.
- [ ] `.env` is listed in `.gitignore`. The repo only contains `.env.example` with placeholder values.
- [ ] `GET /api/token` returns only `clientId` and `idToken`. No `access_token` or any other server-side credential.
- [ ] Server logs **never** record PAN, CVV, or full payment tokens. Mask to last 4 + brand for diagnostic purposes.
- [ ] HTTPS enforced for the entire checkout origin. No mixed content.
- [ ] CSP `script-src` allows `*.paypal.com`, `c.paypal.com`, `www.paypalobjects.com` and any other PayPal-controlled origins your integration uses.
- [ ] CORS rules limit `/api/*` to your own origin(s) only.
- [ ] Rate limiting on `/api/orders`, `/api/orders/:id/capture`, `/api/stc/:cmid` to prevent abuse.

## Configuration

- [ ] `PAYPAL_API_BASE` set to `https://api-m.paypal.com` (production).
- [ ] `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` are from the **Live** application in PayPal Developer dashboard, not Sandbox.
- [ ] `PAYPAL_MERCHANT_ID` matches the live merchant account.
- [ ] `return_url` and `cancel_url` are real, reachable HTTPS URLs on your production domain.
- [ ] SDK loaded from production URL (`https://www.paypal.com/sdk/js`), with the correct live `client-id`.
- [ ] Fraudnet `"s"` field uses the live merchant short name and live `MERCHANT_ID`.
- [ ] OAuth token cache scoped per environment so live and sandbox tokens never mix.

## Functional

- [ ] All amounts and addresses come from server-side cart/customer state. The browser cannot influence them.
- [ ] `customer.id` for Vault uses the real authenticated user ID, not a literal or test value.
- [ ] `PayPal-Request-Id` is a fresh UUID per transaction; reused only within a single Create+Capture pair for retry idempotency.
- [ ] All PayPal-side error codes are mapped to user-friendly messages. No raw stack traces or status codes leak to the buyer.
- [ ] `onError`, `onCancel`, `onWarn` (if BCDC-style flows are present) all have explicit handlers.
- [ ] UI handles `liabilityShift` correctly: capture only on `undefined` or `"POSSIBLE"`; otherwise show retry/alternate path.
- [ ] If the order is created with `payment_source.token`, `Get Order` is checked before deciding to capture.
- [ ] Receipt and confirmation flow stores `purchase_units[0].payments.captures[0].id` for refunds and reconciliation.

## Risk: Fraudnet and STC

- [ ] Fraudnet config script (`fncls`) and library (`fb.js`) inserted into `<body>` exactly once per checkout session.
- [ ] Fraudnet `"f"` field contains the dynamically generated CMID, not a hardcoded value.
- [ ] Fraudnet `"s"` field has the live merchant context: `<MERCHANT_SHORT_NAME>_<MERCHANT_ID>_ACDC`.
- [ ] `POST /api/stc/{cmid}` runs before every Create Order — both new card and saved token paths.
- [ ] `additional_data` in STC body comes from the authenticated user session, not from request body or hardcoded literals.
- [ ] STC errors are logged but never block the buyer from completing checkout.
- [ ] `PayPal-Client-Metadata-Id` header present on **both** Create Order and Capture Order requests.
- [ ] Same CMID is used in Fraudnet `"f"`, STC URL, and the `PayPal-Client-Metadata-Id` headers for the same checkout session.

## Testing

- [ ] Sandbox: full new-card flow with single payment.
- [ ] Sandbox: full new-card flow with MSI (3, 6, 12 months).
- [ ] Sandbox: full new-card flow with IC2B (verified `total_consumer_fee > 0` and `fee_reference_id` propagated).
- [ ] Sandbox: Vault save → list → charge with token → delete.
- [ ] Sandbox: 3DS frictionless success (`liabilityShift === "POSSIBLE"` → capture proceeds).
- [ ] Sandbox: 3DS frictionless failure (capture blocked by code).
- [ ] Sandbox: 3DS step-up success (popup appears, capture proceeds).
- [ ] Sandbox: 3DS step-up failure (popup appears, user fails or cancels, capture blocked).
- [ ] Sandbox: STC simulated failure (e.g., wrong MERCHANT_ID) — checkout still completes.
- [ ] Sandbox: Network failure mid-flow — buyer sees actionable retry, no double-capture.
- [ ] Live: one small real transaction end-to-end with a card you control. Refund through dashboard. Confirm reconciliation reports show the charge and refund.

## Operations

- [ ] Alerting on `POST /api/orders` and `/capture` 5xx rates.
- [ ] Alerting on OAuth refresh failures (`401` from `/v1/oauth2/token`).
- [ ] Dashboards for: capture conversion rate, decline reasons, 3DS challenge rate, MSI vs IC2B mix.
- [ ] Runbook entry for "What to do if PayPal-Client-Metadata-Id is missing in production logs."
- [ ] Webhook endpoints (if used) verified for signature validation and IP allowlisting.

## Documentation

- [ ] Internal handoff doc explains how the CMID flows from browser → STC URL → header.
- [ ] Test cards are referenced by URL to PayPal's Card Testing portal — not pasted into source.
- [ ] PII fields used in STC are documented with their source on your platform (which DB column or session attribute).
- [ ] On-call team has access to PayPal dashboard credentials for incident response.
