# 01 — Architecture: Who Talks to Whom

## The three-tier picture

```
┌──────────────────────────────────────────────────────────────────┐
│  BROWSER (public code — anyone can read it)                      │
│                                                                  │
│   Your HTML/JS                  PayPal SDK (iframes, 3DS modal)  │
│   ┌─────────────────┐           ┌──────────────────────────┐     │
│   │ - app.js        │  ←load→   │ paypal.CardFields(...)   │     │
│   │ - index.html    │           │ paypal.Buttons(...)      │     │
│   │ - Fraudnet      │           └────────────┬─────────────┘     │
│   │   (fb.js)       │                        │ HTTPS direct     │
│   └────────┬────────┘                        │                   │
│            │ HTTPS to /api/*                 │                   │
└────────────┼──────────────────────────────────┼──────────────────┘
             ↓                                  ↓
┌────────────────────────┐          ┌───────────────────────────┐
│  YOUR SERVER (private) │          │  PayPal REST APIs         │
│                        │          │                           │
│  - OAuth2              │ ──HTTPS→ │  api-m.sandbox.paypal.com │
│  - Create Order        │          │  api-m.paypal.com         │
│  - Capture             │          │                           │
│  - Get Order           │          │  /v1/oauth2/token         │
│  - Vault list/delete   │          │  /v2/checkout/orders      │
│  - Financing options   │          │  /v3/vault/payment-tokens │
│  - STC                 │          │  /v1/credit/...           │
│                        │          │  /v1/risk/                │
│  Env vars:             │          │    transaction-contexts   │
│   PAYPAL_CLIENT_ID     │          │                           │
│   PAYPAL_CLIENT_SECRET │          └───────────────────────────┘
│   PAYPAL_API_BASE      │
│   PAYPAL_MERCHANT_ID   │
└────────────────────────┘
```

## Environment variables (server only)

| Variable | Purpose | Where it goes | Example value |
|----------|---------|---------------|---------------|
| `PAYPAL_CLIENT_ID` | Public app identifier. Safe to ship to the browser. | Server reads it; can be exposed via `GET /api/client-id`. | `process.env.PAYPAL_CLIENT_ID` |
| `PAYPAL_CLIENT_SECRET` | Secret. **Never** to the browser. | Server only, used for OAuth Basic auth. | `process.env.PAYPAL_CLIENT_SECRET` |
| `PAYPAL_API_BASE` | REST host. | Server only. | `https://api-m.sandbox.paypal.com` (sandbox) / `https://api-m.paypal.com` (live) |
| `PAYPAL_MERCHANT_ID` | Required for STC URL. | Server only. | `process.env.PAYPAL_MERCHANT_ID` |
| `PORT` | HTTP port. | Server only. | `3000` |

> Put `.env` in `.gitignore`. Provide a `.env.example` with placeholders only.

## Data flow for one transaction (new card)

```
1. Browser loads index.html
2. Browser → GET /api/client-id      → { clientId }
3. Browser → GET /api/token          → { idToken }   (server did OAuth2 internally)
4. Browser generates CMID (32-char UUID, no hyphens)
5. Browser injects Fraudnet config + fb.js  (one time only)
6. Browser loads PayPal JS SDK with data-sdk-client-token=idToken,
                                       data-client-metadata-id=cmid
7. paypal.CardFields(...) renders card iframes
8. User enters card details, picks installments (if shown), clicks Pay
9. Browser → POST /api/stc/{cmid}    (non-blocking, fire-and-forget)
10. Browser → POST /api/orders       body { ...order, _cmid: cmid }
11. Server → POST /v2/checkout/orders + header PayPal-Client-Metadata-Id: cmid
12. SDK may show 3DS challenge if PayPal's risk engine triggers it
13. SDK fires onApprove(data) → browser checks data.liabilityShift
14. Browser → POST /api/orders/{id}/capture body { _cmid: cmid }
15. Server → POST /v2/checkout/orders/{id}/capture + same header
16. UI shows success / failure
```

## Data flow for one transaction (saved token)

```
Steps 1–6 are identical (CMID + Fraudnet + SDK init).
7. Browser → GET /api/vault/payment-tokens?customer_id={your_user_id}
8. UI renders list with brand, last_digits, expiry from response
9. User selects token, picks installments (calls /api/credit/financing-options)
10. Browser → POST /api/stc/{cmid}
11. Browser → POST /api/orders body {
      ...order,
      payment_source: { token: { id: tokenId, type: 'PAYMENT_METHOD_TOKEN' } },
      _cmid: cmid
    }
12. Server → POST /v2/checkout/orders + header PayPal-Client-Metadata-Id: cmid
13. Server → GET /v2/checkout/orders/{id} (capture may have completed automatically)
14. If status !== 'COMPLETED' → POST /v2/checkout/orders/{id}/capture
15. UI shows success / failure
```

## Why the server is a proxy

The browser **never** calls `api-m.paypal.com` directly. Reasons:

1. The `access_token` would have to live in the browser, exposing the merchant's API.
2. The order amount could be tampered with by anyone using browser devtools.
3. Vault and STC endpoints require server credentials.
4. The `PayPal-Client-Metadata-Id` header is added server-side after the browser passes the CMID in the request body (as `_cmid`).

## Where credentials and tokens live

| Item | Location | Lifetime |
|------|----------|----------|
| `CLIENT_ID` | Server env + (optionally) public endpoint to browser | App lifetime |
| `CLIENT_SECRET` | Server env only | App lifetime |
| `access_token` | Server in-memory cache (or Redis) | ~9 hours, refresh with margin |
| `id_token` | Server fetches it on demand and forwards to browser via `/api/token` | Per request, short-lived |
| `cmid` | Browser memory for the duration of one checkout session | Until checkout completes or is abandoned |
| `payment_method_token` (Vault) | Stored by PayPal; merchant only ever holds the opaque ID | Until deleted via DELETE |
