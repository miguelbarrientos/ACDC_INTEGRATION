# 10 — Troubleshooting

A flat, scannable map of symptoms → causes → fixes. Sorted by frequency in real integrations.

## Auth

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| `401 invalid_client` from `/v1/oauth2/token` | CLIENT_ID / SECRET wrong, or env mix-up (sandbox creds against live URL) | Re-check `.env`. Sandbox creds must hit `api-m.sandbox.paypal.com`; live creds must hit `api-m.paypal.com`. |
| `400 unsupported_grant_type` | Body sent as JSON | Set `Content-Type: application/x-www-form-urlencoded` and URL-encode the body. |
| Browser receives `access_token` | Server endpoint accidentally exposes it | Audit `/api/token`; return only `clientId` and `idToken`. |
| 401s every few minutes | Not caching the token | Add caching with a 60s buffer before expiry. |

## Create Order / Capture

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| `UNPROCESSABLE_ENTITY` with field path `purchase_units[0].amount` | Breakdown math doesn't equal `amount.value` | Recompute server-side: `item_total + tax_total + shipping − discount` must equal `amount.value`, all as strings. |
| `UNPROCESSABLE_ENTITY` on items | Numbers sent instead of strings | All money values (`value`, `quantity`) must be strings: `"1"`, `"500.00"`. |
| Capture returns `INSTRUMENT_DECLINED` | Issuer declined — usually risk or insufficient funds | Surface neutral retry message; let buyer try another card. Don't retry automatically more than once. |
| Capture returns `ORDER_NOT_APPROVED` | Calling capture before `onApprove` semantics complete, or after a refund/cancel | Only capture in `onApprove`. For token flows, check `Get Order` first. |
| Duplicate captures | New `PayPal-Request-Id` per retry instead of reusing | Reuse the SAME request UUID for retries of the same logical Create+Capture; new UUID for a new attempt. |

## Tokens / Vault

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Saved cards don't appear on second visit | `customer_id` differs between save and list | Standardize on a single internal user ID (DB primary key, UUID — not email). |
| Token charge succeeded but capture fails with "already captured" | PayPal auto-captured during Create Order | Always `GET /v2/checkout/orders/{id}` after creating with `payment_source.token`; only capture if status is `APPROVED`. |
| Token deleted but still appears in UI | UI cached the old list | Refetch `/api/vault/payment-tokens` after delete; PayPal returns 204 then the next list call won't include it. |
| Card was saved on a failed transaction | `store_in_vault: "ALWAYS"` or wrong default | Use `"ON_SUCCESS"`. |

## Installments (MSI / MCI / IC2B)

> **Reminder:** MCI (Meses Con Intereses) and IC2B (Installments Cost To Buyer) are the same thing — different labels for the same mode. If a developer mentions either one, apply the same diagnosis.

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Months selector empty | Country/currency/amount not eligible, OR you didn't filter `product === 'CARD_ISSUER_INSTALLMENTS'` | Confirm `MX`+`MXN`+sufficient amount; filter+`flatMap` correctly. |
| Only MSI options for token flows; MCI/IC2B options missing | Missing `flow_context.attributes: ['FEE_POLICY_CHARGE_CONSUMER']` | Add it to the `calculated-financing-options` body. This flag unlocks IC2B/MCI options. |
| Submit fails for MCI/IC2B with 422 | `fee_reference_id` missing or stale | Pass the exact `fee_reference_id` from the financing API response. Don't reuse across sessions. For MSI the field is optional; for MCI/IC2B it is mandatory. |
| MSI shown as MCI/IC2B in UI (or vice versa) | UI labels by term count instead of fee | Branch on `parseFloat(option.total_consumer_fee.value) === 0`: zero = MSI, non-zero = MCI/IC2B. |
| `interval_duration` accepted in `submit()` but ignored | Wrong case | SDK's `submit()` is camelCase: `intervalDuration`, `feeReferenceId`. REST is snake_case: `interval_duration`, `fee_reference_id`. |

## 3DS

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| 3DS popup never appears in sandbox | Cardholder name not `3dsuser`, or card not from the 3DS list | Both conditions are required. |
| 3DS popup blocked by browser | `await` between click and `cardField.submit()` killed user activation | Don't await other work in the click handler before submit; do it inside `createOrder`. |
| Captures even when 3DS fails | Code only checks truthiness of `liabilityShift` | Use the explicit check: capture only when `!liabilityShift` OR `liabilityShift === 'POSSIBLE'`. |
| Reading `liability_shift` (snake) → undefined | The SDK delivers it as `liabilityShift` | Fix the property name. |

## Fraudnet / STC

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Fraudnet loads multiple times | No single-load gate | Use a module-level boolean (`fraudnetLoaded`) that persists for the session. |
| `c.paypal.com` blocked by CSP | Default CSP excludes it | Add `c.paypal.com` to `script-src`. |
| STC returns 400 | Bad `additional_data` shape | Ensure `highrisk_txn_flag` is a number, `sender_create_date` matches an accepted ISO format. |
| STC returns 401 | MERCHANT_ID wrong, token expired | Check env; confirm token cache isn't returning a stale token. |
| STC blocks the user when down | Treated as fatal | STC is non-blocking. Always respond 200 to the browser; log failures internally. |
| `PayPal-Client-Metadata-Id` missing on capture | Forgotten to inject on the second call | Add it on Capture too — both calls require it. |
| Different CMIDs across Fraudnet / STC / order | Generated more than once | Generate once per session and reuse everywhere. |

## SDK loading

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| `window.paypal` undefined | SDK script URL malformed or `client-id` missing | Inspect the network tab; the SDK script must return 200 JS, not an HTML error. |
| `cardField.isEligible() === false` | Country/currency/feature flags not enabled for this app | Confirm ACDC eligibility in the merchant account; pick a fallback like PayPal Buttons. |
| Iframes never render | Container IDs in HTML don't match strings passed to `.render()` | Match exactly; check for typos. |
| Multiple Card Fields instances | Re-running `paypal.CardFields(...)` on every navigation | Create once, reuse. |

## How to debug fast

1. **Network tab first.** Confirm `/api/token` is 200, `/api/orders` is 200, `/api/orders/{id}/capture` is 200. Pull the response bodies.
2. **Server logs second.** Make sure you log:
   - `PayPal-Request-Id`
   - `PayPal-Client-Metadata-Id`
   - HTTP status from PayPal
   - `id` of created/captured orders
   - **Never** log PAN/CVV/full tokens. Last 4 + brand only.
3. **Browser console third.** Check for SDK errors, `onError` callbacks.
4. **PayPal sandbox dashboard last.** Find the order by `custom_id`/`invoice_id`, inspect the full lifecycle.
