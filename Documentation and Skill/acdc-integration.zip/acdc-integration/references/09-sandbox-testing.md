# 09 — Sandbox Testing Plan

## Where to get test cards

Use PayPal's official Card Testing portal:

```
https://developer.paypal.com/tools/sandbox/card-testing/
```

> Do not paste test PANs into source code, comments, or this skill. Test card numbers are still 16 digits that pass Luhn checks; corporate DLP/proxies often flag them as real PANs.

For all sandbox tests:
- Any future expiry date
- Any 3- or 4-digit CVV
- Any cardholder name **except** for 3DS scenarios

## Sandbox vs Live URLs

| Item | Sandbox | Live |
|------|---------|------|
| API base | `https://api-m.sandbox.paypal.com` | `https://api-m.paypal.com` |
| SDK script base | `https://www.paypal.com/sdk/js?client-id=...` (works for both; the env follows the client-id) | same |
| Fraudnet `fb.js` | `https://c.paypal.com/da/r/fb.js` | same |

Switching is mostly an env-var change. Live also requires a Live application in your PayPal Developer dashboard with its own client_id/secret/merchant_id.

## Trigger 3DS in sandbox — exactly two conditions

To make 3DS run in sandbox you need **both** at the same time:

1. **Cardholder name = `3dsuser`** (literal string).
2. **Card number from the 3DS list** in the Card Testing portal.

If either is missing, 3DS will not trigger and `liabilityShift` will be `undefined`.

## Recommended end-to-end test plan

Run each scenario top-to-bottom on sandbox before considering the integration done.

### A. Foundation
1. `GET /api/token` returns `clientId` and `idToken`.
2. Page loads, `window.paypal` exists.
3. `paypal.CardFields(...).isEligible()` returns `true`.

### B. New card — single payment
4. Pay with a sandbox-approved card. Verify `onApprove` fires.
5. Capture succeeds; success UI shown.
6. Order shows in your sandbox Business account dashboard.

### C. New card — installments (MSI and IC2B)
7. Set amount that qualifies (e.g., MXN with `transaction_amount > 300`).
8. Confirm months selector appears.
9. Pay with `term=3` MSI. Capture succeeds.
10. Pay with `term=12` IC2B. Confirm `fee_reference_id` is sent on submit.

### D. Vault — save and reuse
11. Pay with new card and check "Recordar tarjeta".
12. Refresh page; call `loadSavedCards(customerId)`. Card appears with brand + last 4.
13. Pay with the saved token. Verify `Get Order` returns `COMPLETED` (or capture explicitly if `APPROVED`).
14. Delete the token. Verify the card is no longer listed.

### E. 3DS Risk Initiated
15. Pay with cardholder name `3dsuser` + a 3DS test card. Verify popup appears (step-up) or doesn't (frictionless).
16. Test a card with successful authentication: `liabilityShift === 'POSSIBLE'` → capture allowed.
17. Test a card with failed authentication: `liabilityShift !== 'POSSIBLE'` → your UI must NOT capture; show retry message.

### F. Fraudnet + STC
18. In DevTools, confirm two scripts inserted into `<body>`: the JSON config with `fncls` and `fb.js`.
19. Confirm Fraudnet loads exactly once (set a breakpoint or counter).
20. Confirm `POST /api/stc/{cmid}` is called before each Create Order.
21. In server logs, confirm `PayPal-Client-Metadata-Id` is set on Create Order **and** Capture Order.
22. Force STC to fail (temporarily wrong `MERCHANT_ID`); confirm checkout still completes.

### G. Negative paths
23. Decline-prone card → expect 4xx from capture; UI shows neutral retry copy.
24. Expired card → expect validation error from Card Fields before submit.
25. Buyer cancels 3DS popup → `onError` or capture-blocked path; UI must allow retry.

## What "done" looks like

For each scenario, capture: status code, response body (excluding any sensitive fields you've redacted), the `id` of the order/capture, and the visible UI state. Keep a short markdown table with one row per scenario for sign-off.

## Switching to Live

Before flipping the switch:

- Replace `PAYPAL_API_BASE`, `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `PAYPAL_MERCHANT_ID` with Live values.
- Replace `return_url` and `cancel_url` with real, HTTPS-reachable URLs on your domain.
- Confirm CSP allows `c.paypal.com` and `*.paypal.com`.
- Run one **small** real charge end-to-end in production with a live card you own. Verify the funds appear in the merchant Live dashboard. Refund afterward.
