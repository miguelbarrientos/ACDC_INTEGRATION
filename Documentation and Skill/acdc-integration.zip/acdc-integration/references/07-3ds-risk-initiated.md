# 07 — 3DS Risk Initiated and `liabilityShift`

## What 3D Secure does, in one paragraph

3D Secure (3DS) is a card-network protocol where the issuer authenticates the cardholder during a transaction (for example, by sending a one-time code to their phone). When 3DS completes successfully, **fraud chargeback liability shifts from the merchant to the issuer**. Without 3DS — or with a failed 3DS — the merchant carries that risk.

## Two integration models — pick one and don't mix

| Model | Who decides if 3DS runs? | What you send | What you read |
|-------|-------------------------|---------------|---------------|
| **3DS Risk Initiated** (this skill) | PayPal's risk engine | Nothing 3DS-specific in Create Order | `data.liabilityShift` in `onApprove` |
| 3DS Merchant Initiated | The merchant | `payment_source.card.attributes.verification` in Create Order | Detailed verification fields in the order response |

This skill covers both models. Risk Initiated is the default; Merchant Initiated is documented in the section below.

## 3DS Merchant Initiated — How to trigger it

In the **Merchant Initiated** model, _you_ decide 3DS runs on every transaction — you do not wait for PayPal's risk engine. The trigger is a single field in the **Create Order** payload:

```js
payment_source: {
  card: {
    attributes: {
      verification: {
        method: "SCA_ALWAYS"   // ← this is the switch
      }
    }
  }
}
```

`SCA_ALWAYS` instructs PayPal to always invoke Strong Customer Authentication, regardless of what the risk engine would otherwise decide.

### What changes vs Risk Initiated

| Behavior | Risk Initiated | Merchant Initiated (`SCA_ALWAYS`) |
|----------|---------------|----------------------------------|
| Who decides if 3DS runs | PayPal risk engine | You (always runs) |
| Create Order payload | No 3DS-specific fields | `payment_source.card.attributes.verification.method: "SCA_ALWAYS"` |
| `onApprove` signal | `data.liabilityShift` (camelCase, from SDK) | Same — still read `data.liabilityShift` |
| Frictionless possible? | Yes | Yes (issuer decides, not you) |
| Use case | General-purpose checkout | Regulatory SCA requirements, high-risk MCC, merchant policy |

### Full Create Order body (Merchant Initiated 3DS)

```js
// POST /v2/checkout/orders
{
  intent: "CAPTURE",
  payment_source: {
    card: {
      attributes: {
        verification: {
          method: "SCA_ALWAYS"
        }
      }
    }
  },
  purchase_units: [{
    amount: {
      currency_code: "MXN",
      value: "{{AMOUNT}}"
    },
    reference_id: "{{ORDER_REF}}"
  }]
}
```

> **Note:** `payment_source.card` here sets card-level attributes. The actual card data (PAN, CVV, expiry) is still captured exclusively through Card Fields iframes and never touches your server.

### `onApprove` handler — identical to Risk Initiated

```js
onApprove: async (data) => {
  if (!('liabilityShift' in data)) {
    await captureOrder(data.orderID);
    return;
  }
  if (data.liabilityShift === 'POSSIBLE') {
    await captureOrder(data.orderID);
    return;
  }
  showError('Autenticación no completada. Intenta de nuevo.');
}
```

The `onApprove` handler is identical regardless of integration model — always check presence first, then value. The SDK delivers the same signals either way.

### When to use `SCA_ALWAYS`

- Your merchant is subject to PSD2 / SCA regulations.
- The MCC or product category is flagged high-risk and you want guaranteed 3DS coverage.
- Internal policy requires 3DS on all card transactions regardless of risk score.

### Pitfalls specific to Merchant Initiated

| Pitfall | Why | Fix |
|---------|-----|-----|
| `SCA_ALWAYS` sent but 3DS still skipped | Account not enabled for Merchant Initiated 3DS | Confirm with PayPal that the feature flag is active on the merchant account |
| Mixing models in the same integration | Sending `SCA_ALWAYS` on some orders and not others | Pick one model per merchant account; do not alternate dynamically |


## The flow

```
You             SDK                 PayPal Risk           Issuer
 │   submit() →   │                       │                  │
 │                │ ─ create order ─────→ │                  │
 │                │                       │ ─ ask issuer ──→ │
 │                │                       │                  │
 │                │ ←── (maybe) ── 3DS popup shown ──────────│
 │                │                       │                  │
 │                │ ←── auth result ──────│←─────────────────│
 │  ← onApprove ──│                       │                  │
 │   (liabilityShift present only if 3DS ran)               │
```

Your single decision point: **first check whether `liabilityShift` is present in `data`** — if it is, 3DS ran and you must evaluate its value; if it is not, the risk engine deemed 3DS unnecessary and you can capture directly.

## Decision matrix

```js
onApprove: async (data) => {
  // When the risk engine decides 3DS is not needed, liabilityShift is simply
  // absent from the data object — the property is not returned at all.
  if (!('liabilityShift' in data)) {
    // No 3DS ran. Risk engine considered it unnecessary. Safe to capture.
    await captureOrder(data.orderID);
    return;
  }

  // 3DS ran — now evaluate the outcome.
  if (data.liabilityShift === 'POSSIBLE') {
    // Frictionless or step-up success. Liability protected. Capture.
    await captureOrder(data.orderID);
    return;
  }

  // liabilityShift is present but not "POSSIBLE" — 3DS ran but no protection.
  showError('La autenticación no se completó. Intenta con otra tarjeta o método.');
}
```

| Condition in `onApprove` | Meaning | Recommended action |
|--------------------------|---------|-------------------|
| `liabilityShift` **absent** (property not in `data`) | Risk engine did not require 3DS — the property is simply not returned | Capture |
| `liabilityShift === "POSSIBLE"` | 3DS ran and succeeded (frictionless or step-up); liability protected | Capture |
| `liabilityShift` present but `!== "POSSIBLE"` (e.g., `"NO"`) | 3DS ran but authentication did not produce protection | **Do not capture.** Show retry/alternate path. |

> **Critical distinction:** `liabilityShift` being absent is not the same as it being `undefined`. The property is genuinely not part of the `data` object when 3DS did not run. Always use `'liabilityShift' in data` to test for its presence, never falsy checks like `!data.liabilityShift` — that pattern conflates "3DS didn't run" with "3DS ran and failed", which are two completely different outcomes requiring different UX.

## Frictionless vs Step-Up

- **Frictionless:** the issuer authenticates silently — no popup. The buyer never knows 3DS ran. `liabilityShift` is present in `onApprove` data (set to `"POSSIBLE"` on success, or another value on failure).
- **Step-Up:** the issuer requests an interactive challenge — popup, OTP, biometric. `liabilityShift` reports the outcome.

You don't choose between these; the issuer does. Your code is the same either way.

## Authentication status codes (when reading detailed responses)

When you call `GET /v2/checkout/orders/{id}` after a 3DS-affected transaction, you can see deeper signals under `purchase_units[].payments.captures[].processor_response` or `payment_source.card.authentication_result`. Reference values:

| `authentication.status` | Meaning |
|-------------------------|---------|
| `Y` | Successful authentication |
| `N` | Failed authentication |
| `A` | Attempted — no proof |
| `U` | Unable — issuer/system unavailable |
| `R` | Rejected by issuer |

Treat `Y` and `A` (with `liability_shift=POSSIBLE`) as proceed; `N`, `U`, `R` typically map to no shift.

## Test cards in Sandbox

> Use placeholders only. The real numbers come from the official PayPal Card Testing portal — never paste them into source code or this skill.

To trigger 3DS in sandbox you need **two conditions simultaneously**:

1. Cardholder name = `3dsuser`
2. Card number from PayPal's Card Testing 3DS list (do **not** paste into your repo; reference the docs URL).

Variants you'll see:

| Scenario | Expected `liability_shift` | UI experience |
|----------|---------------------------|---------------|
| Frictionless success | `POSSIBLE` | No popup |
| Frictionless failure | `N` | No popup, but `onApprove` should be blocked from capture |
| Step-Up success | `POSSIBLE` | Popup appears; user completes |
| Step-Up failure | `N` | Popup appears; user fails or cancels |
| Attempts Stand-In | `POSSIBLE` (status `A`) | No popup; treat as success |
| Issuer not available | `N` (status `U`) | Treat as failure |

## What you must NOT do

- Don't try to "force" 3DS from the backend on a Risk Initiated integration. That's a different integration model.
- Don't capture on `liabilityShift !== "POSSIBLE"` and try to absorb the chargeback risk yourself. The whole point of 3DS is shifting liability — bypassing it defeats the protection.
- Don't show technical error codes to the buyer. Use neutral, retry-friendly copy.

## Pitfalls

| Pitfall | Why | Fix |
|---------|-----|-----|
| Captures succeed even when 3DS failed | Used `!data.liabilityShift` which collapses "absent" and "NO" into the same branch, then captured when `liabilityShift` was absent | Use `'liabilityShift' in data` first; only then check `=== 'POSSIBLE'`. |
| 3DS popup blocked | `await` between click and `cardField.submit()` killed the user activation | Avoid awaiting inside the click handler before calling submit; do work inside `createOrder`. |
| Test 3DS doesn't trigger | Forgot to set cardholder name to `3dsuser` | Both conditions are required: name + card number from the 3DS list. |
| Inconsistent `liabilityShift` values | Reading `liability_shift` (snake) instead of `liabilityShift` (camel) | The SDK delivers it as `liabilityShift`. |
