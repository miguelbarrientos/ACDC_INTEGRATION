# 05 — MSI y MCI / IC2B

## ⚠️ Terminología — obligatorio leer primero

Hay dos productos de financiamiento a meses en PayPal. Son opuestos; nunca los agrupes.

| Producto | Nombre completo | Español correcto | ❌ Nunca decir |
|----------|----------------|-----------------|----------------|
| **MSI / Installments** | MSI = Meses Sin Intereses. **Installments es el nombre en inglés de MSI** — mismo producto. | "Meses Sin Intereses", "MSI", "Installments" | "instalamentos", "MSI (o IC2B)" |
| **IC2B / MCI** | IC2B = **Installments Cost To Buyer** (esas son las siglas). MCI = Meses Con Intereses. Mismo producto, distinto idioma. | "Meses Con Intereses", "MCI", "IC2B", "pagos diferidos" | "instalamentos con costo", "MSI (o IC2B)" |

## La distinción más importante

| | **MSI / Installments** — Meses Sin Intereses | **IC2B / MCI** — Installments Cost To Buyer / Meses Con Intereses |
|--|----------------------------------------------|------------------------------------------------------------------|
| ¿Quién paga el financiamiento? | El **comercio** (lo absorbe); el comprador paga precio de contado | El **comprador** paga un cargo adicional sobre el precio |
| `total_consumer_fee.value` | `"0.00"` | `> "0.00"` |
| `fee_reference_id` en submit | Opcional en algunos planes | **Obligatorio** |
| Etiqueta UI (español) | `"3 meses sin intereses"` | `"6 meses — cargo $45.00 MXN"` |

Classification rule (works for both new-card SDK callbacks and saved-card API responses):

```js
const isMSI = parseFloat(option.total_consumer_fee.value) === 0;
// isMSI === false → this is MCI (Meses Con Intereses) = IC2B (Installments Cost To Buyer)
```

## Two flows, two APIs

| Buyer is paying with | Where you get the months | Endpoint / Hook |
|----------------------|--------------------------|-----------------|
| New card (Card Fields) | SDK callbacks | `installments.onInstallmentsRequested` and `onInstallmentsAvailable` |
| Saved card (Vault token) | REST API | `POST /v1/credit/calculated-financing-options` |

Build a single `populateMonthsSelect(financingOptions)` function that handles both — the option shape is identical.

## Flow 1 — New card via SDK callbacks

Inside your `paypal.CardFields({ ... })` config:

```js
installments: {
  // PayPal asks for context; you reply with amount + country.
  onInstallmentsRequested: () => {
    const cart = readCartFromYourState(); // server-validated shape
    return {
      financing_country_code: 'MX',
      transaction_amount: {
        value:         cart.totalString,    // "1000.00"
        currency_code: cart.currency,       // "MXN"
      },
      billing_address: { country_code: 'MX' },
      includeBuyerInstallments: true,       // required for MX to surface IC2B
    };
  },

  // PayPal returns the menu; you render it.
  onInstallmentsAvailable: ({ financing_options }) => {
    const issuerOptions = financing_options
      .filter(opt => opt.product === 'CARD_ISSUER_INSTALLMENTS')
      .flatMap(opt => opt.qualifying_financing_options);

    const select = document.querySelector('#installments-select');
    select.innerHTML = '<option value="">1 pago</option>';

    issuerOptions.forEach((opt, i) => {
      const isMSI = parseFloat(opt.total_consumer_fee.value) === 0;
      const label = isMSI
        ? `${opt.credit_financing.term} meses sin intereses`
        : `${opt.credit_financing.term} meses — cargo $${opt.total_consumer_fee.value} ${opt.total_consumer_fee.currency_code}`;

      const o = document.createElement('option');
      o.value = i;
      o.textContent = label;
      // Stash the data needed at submit time.
      o.dataset.term            = opt.credit_financing.term;
      o.dataset.intervalDuration = opt.credit_financing.interval_duration; // "P1M"
      o.dataset.feeReferenceId  = opt.fee_reference_id || '';
      select.appendChild(o);
    });
  },
}
```

### Submitting the new-card form with months

```js
// On Pay click:
const select = document.querySelector('#installments-select');
const opt    = select.selectedOptions[0];
const term   = parseInt(opt.dataset.term || '1', 10);

if (term <= 1) {
  await cardField.submit({}); // single payment
} else {
  await cardField.submit({
    installments: {
      term,
      intervalDuration: opt.dataset.intervalDuration, // SDK uses camelCase
      feeReferenceId:   opt.dataset.feeReferenceId,   // required for IC2B
    },
  });
}
```

> ⚠️ **Naming convention trap:** REST uses `snake_case` (`interval_duration`, `fee_reference_id`); the SDK's `submit()` uses `camelCase` (`intervalDuration`, `feeReferenceId`). Mixing them is a top-3 bug in real integrations.

## Flow 2 — Saved card via REST API

The SDK callbacks don't fire for token flows; you must call PayPal directly from your server.

### Server proxy

```js
app.post('/api/credit/financing-options', async (req, res) => {
  try {
    const { tokenId, amount, currencyCode } = req.body;
    const { access_token } = await generateAccessToken();

    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v1/credit/calculated-financing-options`,
      {
        method:  'POST',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
        body: JSON.stringify({
          financing_country_code: 'MX',
          transaction_amount:     { value: amount, currency_code: currencyCode },
          funding_instrument: {
            type: 'TOKEN',
            token: {
              type: 'PAYMENT_METHOD_TOKEN',
              payment_method_token: tokenId,
            },
          },
          flow_context: {
            // Without this, the API often returns ONLY MSI options (no IC2B).
            attributes: ['FEE_POLICY_CHARGE_CONSUMER'],
          },
        }),
      }
    );
    res.status(r.status).json(await r.json());
  } catch (err) { res.status(500).json({ error: err.message }); }
});
```

### Frontend uses the same renderer

```js
async function loadInstallmentsForToken(tokenId, amount, currency) {
  const r = await fetch('/api/credit/financing-options', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ tokenId, amount, currencyCode: currency }),
  });
  const data = await r.json();
  populateMonthsSelect(data.financing_options || []);
}
```

`populateMonthsSelect` can be the same function used in `onInstallmentsAvailable` — the option shape is identical.

## Sample API response (both MSI and IC2B in one array)

```json
{
  "financing_options": [
    {
      "product": "CARD_ISSUER_INSTALLMENTS",
      "qualifying_financing_options": [
        {
          "credit_financing": { "term": 3,  "interval_duration": "P1M" },
          "monthly_payment":   { "value": "333.33", "currency_code": "MXN" },
          "total_consumer_fee":{ "value": "0.00",  "currency_code": "MXN" },
          "fee_reference_id":  "ref_msi_3"
        },
        {
          "credit_financing": { "term": 12, "interval_duration": "P1M" },
          "monthly_payment":   { "value": "95.00",  "currency_code": "MXN" },
          "total_consumer_fee":{ "value": "140.00", "currency_code": "MXN" },
          "fee_reference_id":  "ref_ic2b_12"
        }
      ]
    }
  ]
}
```

## Submitting Create Order with installments on a saved token

The `payment_source.token` block gains an `attributes.installments`:

```json
"payment_source": {
  "token": {
    "id":   "{{PAYMENT_METHOD_TOKEN_ID}}",
    "type": "PAYMENT_METHOD_TOKEN",
    "attributes": {
      "installments": {
        "term": 6,
        "interval_duration": "P1M",
        "fee_reference_id": "{{FEE_REFERENCE_ID_FROM_FINANCING_API}}"
      }
    }
  }
}
```

Note: REST = `snake_case` here (`interval_duration`, `fee_reference_id`).

## Pitfalls

| Pitfall | Why | Fix |
|---------|-----|-----|
| Months selector is empty | Country/currency/amount not eligible, or you forgot to filter `product === 'CARD_ISSUER_INSTALLMENTS'` | Confirm `MX` + `MXN`, then filter and `flatMap` properly. |
| Only MSI options for token flows | Missing `flow_context.attributes: ['FEE_POLICY_CHARGE_CONSUMER']` | Add it; that flag opens the IC2B options. |
| `UNPROCESSABLE_ENTITY` on Create Order with months | `fee_reference_id` missing or stale | Always pass the exact `fee_reference_id` that came back with that option. Don't reuse across sessions. |
| MSI and IC2B labels look the same in UI | UI only shows term count | Read `total_consumer_fee.value` and label accordingly. |
| Mixing snake_case and camelCase | SDK `submit()` is camelCase; REST is snake_case | Memorize the table or copy from this reference. |
