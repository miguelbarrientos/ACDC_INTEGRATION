# 03 — Card Fields on the Frontend

## Mental model

PayPal renders four `<iframe>` elements inside containers you provide. The DOM you ship has empty `<div>`s; the SDK fills them. The PAN, CVV, expiry, and cardholder name **live inside PayPal's iframes**, never in the merchant DOM.

```
Your page                          PayPal iframes (your DOM, their content)
┌──────────────────────┐           ┌──────────────────────┐
│ #card-number-...     │  ←mount→  │ <iframe> Card number │
│ #card-expiry-...     │  ←mount→  │ <iframe> Expiry      │
│ #card-cvv-...        │  ←mount→  │ <iframe> CVV         │
│ #card-name-...       │  ←mount→  │ <iframe> Name        │
└──────────────────────┘           └──────────────────────┘
```

Consequence: your CSS can style the **container** but not the input inside the iframe. Inside the iframe you style with the SDK's `style` object using a **whitelist** of CSS properties (see below).

## Required HTML containers

```html
<!-- Containers for SDK iframes (IDs must match selectors in render()) -->
<div id="card-number-field-container"></div>
<div id="card-expiry-field-container"></div>
<div id="card-cvv-field-container"></div>
<div id="card-name-field-container"></div>

<!-- Optional: installments selector -->
<select id="installments-select">
  <option value="">Sin meses (1 pago)</option>
  <!-- options injected by onInstallmentsAvailable -->
</select>

<!-- Optional: Vault opt-in -->
<label>
  <input type="checkbox" id="vault" />
  Recordar esta tarjeta para próximas compras
</label>

<!-- Submit button: must call cardField.submit(...) on click -->
<button id="card-field-submit" type="button">Pagar</button>
```

> Reference stylesheet for the containers: `https://www.paypalobjects.com/webstatic/en_US/developer/docs/css/cardfields.css`. Use it as a base then override in your own CSS.

## SDK URL and script tag

```html
<script
  src="https://www.paypal.com/sdk/js?client-id={{CLIENT_ID}}&components=buttons,card-fields&currency=MXN&locale=es_MX"
  data-sdk-client-token="{{ID_TOKEN}}"
  data-client-metadata-id="{{CMID}}"
></script>
```

| Attribute | Why it matters |
|-----------|---------------|
| `client-id` | Resolves which merchant app is initializing the SDK. Public. |
| `components` | Use only what you need. `buttons,card-fields` is the typical ACDC bundle. |
| `currency` | Must match the currency of your `purchase_units`. |
| `locale` | BCP-47 (e.g., `es_MX`, `en_US`). Drives SDK UI text and 3DS modal language. |
| `data-sdk-client-token` | The `id_token` from your server. Bootstraps the SDK with merchant identity. |
| `data-client-metadata-id` | The CMID. **Same value** as Fraudnet's `"f"` and the `PayPal-Client-Metadata-Id` header. |

## Initializing Card Fields

```js
// app.js — after the SDK script has loaded
async function renderCardFields({ cmid, getCart }) {
  if (!window.paypal || !paypal.CardFields) {
    throw new Error('PayPal SDK not loaded');
  }

  const cardField = paypal.CardFields({
    style: {
      input: { 'font-size': '16px', 'font-family': 'system-ui, sans-serif' },
      '.invalid': { color: '#d8000c' },
      ':focus':   { color: '#0070ba' },
    },

    createOrder: async () => {
      // Always rebuild from server-side state (cart). Never trust browser-held totals.
      const cart  = await getCart();
      const cmidB = cmid;

      // STC just before Create Order — fire and forget
      fetch(`/api/stc/${cmidB}`, { method: 'POST' }).catch(() => {});

      const res = await fetch('/api/orders', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ ...buildOrderPayload(cart), _cmid: cmidB }),
      });
      const order = await res.json();
      if (!res.ok) throw new Error(`createOrder ${res.status}: ${JSON.stringify(order)}`);
      return order.id;
    },

    onApprove: async (data) => {
      // 3DS Risk Initiated — decide based on liabilityShift
      if (data.liabilityShift && data.liabilityShift !== 'POSSIBLE') {
        showError('La autenticación 3DS no se completó. Intenta con otra tarjeta.');
        return;
      }
      const res = await fetch(`/api/orders/${data.orderID}/capture`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ _cmid: cmid }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(`capture ${res.status}: ${JSON.stringify(result)}`);
      showSuccess(result);
    },

    onError: (err) => {
      console.error('CardFields onError:', err);
      showError('Ocurrió un error procesando el pago. Intenta de nuevo.');
    },

    installments: {
      // see references/05-installments-msi-ic2b.md
      onInstallmentsRequested: () => buildInstallmentsRequest(getCart()),
      onInstallmentsAvailable: ({ financing_options }) => populateMonthsSelect(financing_options),
    },
  });

  if (!cardField.isEligible()) {
    // Country/currency/feature flags don't allow Card Fields here.
    // Fall back to PayPal Buttons, or hide the card section entirely.
    return null;
  }

  cardField.NumberField().render('#card-number-field-container');
  cardField.ExpiryField().render('#card-expiry-field-container');
  cardField.CVVField().render('#card-cvv-field-container');
  cardField.NameField().render('#card-name-field-container');

  document.querySelector('#card-field-submit').addEventListener('click', async () => {
    const monthsOption = readSelectedInstallment(); // term, intervalDuration, feeReferenceId or null
    const submitArgs = monthsOption && monthsOption.term > 1
      ? { installments: monthsOption }
      : {};
    try {
      await cardField.submit(submitArgs);
      // onApprove will fire on success.
    } catch (err) {
      // Validation/3DS rejection, etc. — surface a user-friendly message.
      showError(extractFriendlyMessage(err));
    }
  });

  return cardField;
}
```

## Style object — what's allowed

Allowed selectors: `input`, `.invalid`, `:focus`, `:hover`.

Allowed properties (everything else is silently ignored by the SDK for security):

`color, font, font-family, font-size, font-size-adjust, font-stretch, font-style, font-variant, font-variant-alternates, font-variant-caps, font-variant-east-asian, font-variant-ligatures, font-variant-numeric, font-weight, line-height, letter-spacing, opacity, outline, text-shadow, transition, padding, padding-top, padding-right, padding-bottom, padding-left`.

Backgrounds, borders, sizes — control those on the **container** with normal CSS.

## Eligibility check

`paypal.CardFields(...).isEligible()` returns a boolean. If `false`:

- The merchant account/app may not have ACDC enabled for the buyer's country/currency.
- The browser may not be supported (rare).

Always render a fallback (PayPal Buttons, PayLater, or a clear "card payments unavailable" message) so the user is never stuck.

## Pitfalls

1. **Awaiting before `submit` inside the click handler kills the user activation** in some browsers, blocking 3DS popups. Don't `await` other work between the click and `submit`; do it inside `createOrder`.
2. **Container IDs must match the strings you pass to `.render()`** exactly. A typo silently no-ops.
3. **Multiple Card Fields instances on the same page** — don't. Create one and reuse it.
4. **Missing `installments` block** — if you don't define it, the months selector simply never appears, even if the country/amount qualify.
