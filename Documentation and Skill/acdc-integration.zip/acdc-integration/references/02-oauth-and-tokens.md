# 02 — OAuth2 and the id_token

## What you're getting and why

`POST /v1/oauth2/token` with `grant_type=client_credentials&response_type=id_token` returns two things:

| Field | Purpose | Where it goes |
|-------|---------|---------------|
| `access_token` | Bearer token for **all** server-to-server REST calls (Orders, Vault, STC, Credit). | **Server only.** Never to the browser. |
| `id_token` | Short-lived JWT that the JS SDK uses (via `data-sdk-client-token`) to bootstrap securely without exposing your secret. | Forwarded to the browser via your own `GET /api/token` endpoint. |

> If you don't add `response_type=id_token`, you only get `access_token` back. The SDK works with just `client-id` for many flows, but Card Fields with Vault and certain advanced features prefer the `id_token` so PayPal can correlate the SDK session with the merchant credentials.

## The Basic auth header

```
Authorization: Basic base64(CLIENT_ID:CLIENT_SECRET)
Content-Type:  application/x-www-form-urlencoded

grant_type=client_credentials&response_type=id_token
```

## Reference Node.js implementation (with caching and concurrent-call safety)

```js
const TOKEN_EXPIRY_BUFFER_MS = 60 * 1000; // refresh 60s before expiry

const oauthCache = {
  accessToken: null,
  idToken:     null,
  expiresAt:   0,
  pending:     null, // shared promise during refresh
};

async function generateAccessToken() {
  const now = Date.now();
  if (oauthCache.accessToken && oauthCache.expiresAt > now) {
    return { access_token: oauthCache.accessToken, id_token: oauthCache.idToken };
  }
  if (oauthCache.pending) return oauthCache.pending;

  oauthCache.pending = (async () => {
    const credentials = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const res = await fetch(`${process.env.PAYPAL_API_BASE}/v1/oauth2/token`, {
      method:  'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type':  'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials&response_type=id_token',
    });

    if (!res.ok) throw new Error(`OAuth2 ${res.status}: ${await res.text()}`);
    const data = await res.json();

    const ttlMs = Number(data.expires_in || 0) * 1000;
    oauthCache.accessToken = data.access_token;
    oauthCache.idToken     = data.id_token;
    oauthCache.expiresAt   = Date.now() + Math.max(ttlMs - TOKEN_EXPIRY_BUFFER_MS, 0);
    return { access_token: data.access_token, id_token: data.id_token };
  })();

  try   { return await oauthCache.pending; }
  finally { oauthCache.pending = null; }
}
```

### Why the cache matters
- A naive integration calls OAuth on every request → unnecessary latency, throttling risk.
- Tokens last ~9 h; cache them in memory (single instance) or Redis (multi-instance).
- The `pending` promise prevents a thundering herd when the token expires and many requests arrive simultaneously.

## The browser-facing endpoint

```js
// GET /api/token — exposes only what the browser needs
app.get('/api/token', async (_req, res) => {
  try {
    const { id_token } = await generateAccessToken();
    res.json({
      clientId: process.env.PAYPAL_CLIENT_ID, // public, OK to send
      idToken:  id_token,                     // public, JWT, short-lived
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
```

> The browser uses `clientId` to build the SDK URL (`https://www.paypal.com/sdk/js?client-id=...`) and sets `data-sdk-client-token={idToken}` on the `<script>` tag.

## cURL test

```bash
# In a server-side terminal (never the browser):
CREDS=$(echo -n "$PAYPAL_CLIENT_ID:$PAYPAL_CLIENT_SECRET" | base64)
curl -X POST "$PAYPAL_API_BASE/v1/oauth2/token" \
  -H "Authorization: Basic $CREDS" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&response_type=id_token"
```

Expected: `200 OK` with `access_token`, `id_token`, `expires_in`, `scope`, `token_type: "Bearer"`.

## Common failures

| Symptom | Cause | Fix |
|---------|-------|-----|
| `401 invalid_client` | Wrong CLIENT_ID/SECRET, or wrong env (sandbox vs live) | Verify `.env`. App-level credentials are scoped to one environment. |
| `400 unsupported_grant_type` | Body sent as JSON instead of `x-www-form-urlencoded` | Set `Content-Type` correctly, send body as URL-encoded. |
| `id_token` not in response | Forgot `response_type=id_token` | Add it to the body. |
| Browser sees `access_token` | You exposed it accidentally | Audit `/api/token`; only return `clientId` and `idToken`. |
