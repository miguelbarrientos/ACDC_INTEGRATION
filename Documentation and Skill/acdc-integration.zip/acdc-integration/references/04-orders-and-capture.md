# 04 — Orders v2: Create, Capture, Get

## The two endpoints, and why you have both

| Action | PayPal endpoint | Your proxy | Purpose |
|--------|----------------|-----------|---------|
| Create Order | `POST /v2/checkout/orders` | `POST /api/orders` | Reserve an intent to charge with amount, currency, line items, payer, shipping, and (optionally) `payment_source` for vault/token flows. |
| Capture Order | `POST /v2/checkout/orders/{id}/capture` | `POST /api/orders/{id}/capture` | Actually move the money. Until you capture, no funds are taken. |
| Get Order | `GET /v2/checkout/orders/{id}` | `GET /api/orders/{id}` | Inspect status. **Required after creating an order with `payment_source.token`** because PayPal may have already auto-captured. |

Required server headers on Create Order and Capture:

```
Authorization: Bearer {access_token}
Content-Type:  application/json
PayPal-Request-Id: {uuid v4}              ← idempotency, same UUID across Create+Capture, new per attempt
PayPal-Client-Metadata-Id: {cmid}         ← required when Fraudnet/STC are in use
Prefer: return=representation             ← optional; full body in response
```

## Full Create Order payload (production-shaped, no minimal version)

> Use placeholders. Never hardcode amounts; build them server-side from the cart.

```json
{
  "intent": "CAPTURE",
  "application_context": {
    "brand_name": "{{BRAND_NAME}}",
    "locale": "es-MX",
    "shipping_preference": "SET_PROVIDED_ADDRESS",
    "user_action": "PAY_NOW",
    "return_url": "{{RETURN_URL}}",
    "cancel_url": "{{CANCEL_URL}}"
  },
  "payer": {
    "email_address": "{{BUYER_EMAIL}}",
    "name": { "given_name": "{{BUYER_FIRST}}", "surname": "{{BUYER_LAST}}" },
    "phone": {
      "phone_type": "MOBILE",
      "phone_number": { "national_number": "{{BUYER_PHONE_DIGITS}}" }
    }
  },
  "purchase_units": [
    {
      "invoice_id":  "{{INVOICE_ID}}",
      "custom_id":   "{{INTERNAL_ORDER_ID}}",
      "description": "{{ORDER_DESCRIPTION}}",
      "amount": {
        "currency_code": "{{CURRENCY}}",
        "value":         "{{TOTAL}}",
        "breakdown": {
          "item_total": { "currency_code": "{{CURRENCY}}", "value": "{{ITEM_TOTAL}}" },
          "tax_total":  { "currency_code": "{{CURRENCY}}", "value": "{{TAX_TOTAL}}" },
          "shipping":   { "currency_code": "{{CURRENCY}}", "value": "{{SHIPPING_TOTAL}}" },
          "discount":   { "currency_code": "{{CURRENCY}}", "value": "{{DISCOUNT_TOTAL}}" }
        }
      },
      "items": [
        {
          "name":        "{{ITEM_NAME}}",
          "description": "{{ITEM_DESCRIPTION}}",
          "sku":         "{{SKU}}",
          "quantity":    "{{QTY}}",
          "unit_amount": { "currency_code": "{{CURRENCY}}", "value": "{{UNIT_PRICE}}" },
          "tax":         { "currency_code": "{{CURRENCY}}", "value": "{{UNIT_TAX}}" },
          "category":    "PHYSICAL_GOODS"
        }
      ],
      "shipping": {
        "name": { "full_name": "{{SHIPPING_FULL_NAME}}" },
        "address": {
          "address_line_1": "{{LINE_1}}",
          "address_line_2": "{{LINE_2}}",
          "admin_area_2":   "{{CITY}}",
          "admin_area_1":   "{{STATE}}",
          "postal_code":    "{{POSTAL}}",
          "country_code":   "{{ISO_ALPHA_2}}"
        }
      }
    }
  ]
}
```

### Breakdown math (this is what 422s)

```
item_total       = Σ (unit_amount × quantity) per item
tax_total        = Σ (item.tax × quantity) per item
amount.value     = item_total + tax_total + shipping − discount
```

If the math is off by even one cent, PayPal returns `UNPROCESSABLE_ENTITY`. All values are **strings**, not numbers (PayPal is strict).

## Adding payment context for new card with Vault opt-in

Append to the root of the payload:

```json
"payment_source": {
  "card": {
    "attributes": {
      "customer": { "id": "{{INTERNAL_USER_ID}}" },
      "vault": {
        "store_in_vault": "ON_SUCCESS",
        "usage_type": "MERCHANT",
        "customer_type": "CONSUMER",
        "permit_multiple_payment_tokens": true
      }
    }
  }
}
```

`store_in_vault: "ON_SUCCESS"` saves the card only if the transaction succeeds.

## Adding payment context for saved-card flow

```json
"payment_source": {
  "token": {
    "id":   "{{PAYMENT_METHOD_TOKEN_ID}}",
    "type": "PAYMENT_METHOD_TOKEN"
  }
}
```

If the buyer chose installments > 1 for the saved card, append `attributes.installments` (see `references/05-installments-msi-ic2b.md`).

## Server proxy for Create Order

```js
const { randomUUID } = require('crypto');

app.post('/api/orders', async (req, res) => {
  try {
    const { _cmid, ...orderPayload } = req.body;
    const { access_token } = await generateAccessToken();

    const requestId = randomUUID(); // store this if you intend to retry
    const headers = {
      'Content-Type':       'application/json',
      'Authorization':      `Bearer ${access_token}`,
      'PayPal-Request-Id':  requestId,
    };
    if (_cmid) headers['PayPal-Client-Metadata-Id'] = _cmid;

    const r = await fetch(`${process.env.PAYPAL_API_BASE}/v2/checkout/orders`, {
      method:  'POST',
      headers,
      body:    JSON.stringify(orderPayload),
    });
    const body = await r.json();
    res.status(r.status).json(body);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
```

## Server proxy for Capture Order

```js
app.post('/api/orders/:orderId/capture', async (req, res) => {
  try {
    const { _cmid } = req.body || {};
    const { access_token } = await generateAccessToken();

    const headers = {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${access_token}`,
      // Reuse the SAME PayPal-Request-Id you used for Create Order if you stored it.
      // For a brand-new attempt of a different transaction, generate a new one.
    };
    if (_cmid) headers['PayPal-Client-Metadata-Id'] = _cmid;

    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v2/checkout/orders/${req.params.orderId}/capture`,
      { method: 'POST', headers, body: JSON.stringify({}) }
    );
    const body = await r.json();
    res.status(r.status).json(body);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
```

## Get Order (especially after token-based Create)

```js
app.get('/api/orders/:orderId', async (req, res) => {
  try {
    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v2/checkout/orders/${req.params.orderId}`,
      {
        method:  'GET',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    res.status(r.status).json(await r.json());
  } catch (err) { res.status(500).json({ error: err.message }); }
});
```

When the status comes back as `COMPLETED`, the capture already happened automatically (common with `payment_source.token`); your UI should jump straight to the success state. If `APPROVED`, capture explicitly.

## What's in a successful Capture response

```json
{
  "id": "{{ORDER_ID}}",
  "status": "COMPLETED",
  "purchase_units": [{
    "payments": {
      "captures": [{
        "id": "{{CAPTURE_ID}}",
        "status": "COMPLETED",
        "amount": { "currency_code": "{{CURRENCY}}", "value": "{{TOTAL}}" },
        "create_time": "...",
        "update_time": "..."
      }]
    }
  }]
}
```

Persist `purchase_units[0].payments.captures[0].id` — that's what you'll need for refunds, reconciliation, and dispute responses.

## Pitfalls

| Pitfall | What you'll see | Fix |
|---------|----------------|-----|
| Off-by-one in breakdown | `UNPROCESSABLE_ENTITY` with field path `purchase_units[0].amount` | Recompute breakdown on the server with the same rounding rules. |
| Missing `currency_code` consistency | 4xx | All amounts in one order must share the same `currency_code`. |
| Sending numbers instead of strings | 4xx | `"1"` not `1`, `"500.00"` not `500`. |
| Hardcoded `return_url` like `localhost` | Browser hangs on redirect after PayPal popup | Use real https URLs in production. |
| Not capturing when token flow returned `COMPLETED` already | Phantom "uncaptured" alerts | Always `GET /orders/:id` before deciding to capture in token flows. |
| Forgetting `PayPal-Client-Metadata-Id` | Risk signals don't correlate | Always inject it on Create Order **and** Capture Order. |
