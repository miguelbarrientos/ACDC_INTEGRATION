# 08 — Fraudnet (client) + STC (server) + the CMID that ties them together

## What problem these solve

Card-not-present fraud is hard to spot from a payment payload alone. PayPal augments the order with two streams of risk signals:

1. **Fraudnet** — a JavaScript snippet running in the buyer's browser that fingerprints the device, network, and behavior and ships those signals to PayPal Risk.
2. **STC (Set Transaction Context)** — a server-to-server PUT call where the merchant attaches identity and history about the buyer (sender_email, account_create_date, trust level, etc.).

Both must be **correlated to the order**. That's the job of the **CMID**.

## The CMID — one ID, three places

A 32-character UUID v4 with hyphens removed. Generated once per checkout session and used in:

1. The Fraudnet config script — field `"f"`.
2. The STC URL — `PUT /v1/risk/transaction-contexts/{merchantId}/{cmid}`.
3. The header `PayPal-Client-Metadata-Id` on Create Order **and** Capture Order.

```js
function generateCMID() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID().replace(/-/g, ''); // 32 chars no hyphens
  }
  // Fallback for older browsers
  return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}
```

> Generate it once per checkout session. **Do not** regenerate when the buyer retries a failed payment or switches between new card and saved card. Generate a new CMID only for a brand-new transaction (after success or hard cancel).

## Fraudnet — client side

Two scripts, injected once per session:

```html
<!-- Script 1: configuration JSON -->
<script type="application/json"
  fncls="fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99">
{
  "f": "{{CMID}}",
  "s": "{{MERCHANT_SHORT_NAME}}_{{PAYPAL_MERCHANT_ID}}_ACDC"
}
</script>

<!-- Script 2: the Fraudnet library -->
<script type="text/javascript" src="https://c.paypal.com/da/r/fb.js"></script>
```

Field reference:

| Field | Value | Notes |
|-------|-------|-------|
| `fncls` | `fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99` | Fixed identifier for the config block. **Never change.** |
| `"f"` | The CMID | Same value as STC URL and `PayPal-Client-Metadata-Id` header. |
| `"s"` | `{{MERCHANT_SHORT_NAME}}_{{PAYPAL_MERCHANT_ID}}_ACDC` | Page/merchant context. Product is always `ACDC` for Card Fields. |

Dynamic injection (recommended):

```js
let fraudnetLoaded = false;

function loadFraudnet(cmid) {
  if (fraudnetLoaded) return;
  fraudnetLoaded = true;

  const merchantShort = process.env.MERCHANT_SHORT_NAME // injected at build/render time
                     || window.__APP_CONFIG__.merchantShortName;
  const merchantId    = window.__APP_CONFIG__.paypalMerchantId;

  const cfg = document.createElement('script');
  cfg.type = 'application/json';
  cfg.setAttribute('fncls', 'fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99');
  cfg.textContent = JSON.stringify({
    f: cmid,
    s: `${merchantShort}_${merchantId}_ACDC`,
  });
  document.body.appendChild(cfg);

  const lib = document.createElement('script');
  lib.type = 'text/javascript';
  lib.src  = 'https://c.paypal.com/da/r/fb.js';
  document.body.appendChild(lib);
}
```

Loading rules:

- ✅ Load **once** when the checkout initializes.
- ✅ Same load covers both new card and saved card flows.
- ❌ Do **not** reload on payment retries within the same session.
- ❌ Do **not** reload when switching between new and saved card.
- ✅ Generate a new CMID and reload Fraudnet only when starting a brand-new transaction (post-success or hard cancel).

CSP note: ensure `c.paypal.com` is allowed in `script-src`.

## STC — server side, non-blocking

`STC` enriches the order with identity context. **Always** call it just before Create Order, in both new card and token flows. It is **non-blocking** — log errors but never stop checkout.

### Endpoint

```
PUT {{API_BASE}}/v1/risk/transaction-contexts/{{PAYPAL_MERCHANT_ID}}/{{CMID}}
Authorization: Bearer {{access_token}}
Content-Type:  application/json
```

### Body shape

```json
{
  "additional_data": [
    { "key": "sender_account_id",   "value": "{{INTERNAL_USER_ID}}" },
    { "key": "sender_first_name",   "value": "{{BUYER_FIRST}}" },
    { "key": "sender_last_name",    "value": "{{BUYER_LAST}}" },
    { "key": "sender_email",        "value": "{{BUYER_EMAIL}}" },
    { "key": "sender_phone",        "value": "{{BUYER_PHONE_DIGITS}}" },
    { "key": "sender_country_code", "value": "{{ISO_ALPHA_2}}" },
    { "key": "sender_create_date",  "value": "{{ACCOUNT_CREATED_ISO}}" },
    { "key": "highrisk_txn_flag",   "value": 0 },
    { "key": "vertical",            "value": "{{VERTICAL}}" },
    { "key": "cd_string_one",       "value": "{{TRUST_LEVEL}}" }
  ]
}
```

### Field reference

| Key | Type | Description | Notes |
|-----|------|-------------|-------|
| `sender_account_id` | string | Buyer's stable ID on your platform | Do not send raw email or session ID |
| `sender_first_name` | string | Given name | Plain text |
| `sender_last_name` | string | Family name | Plain text |
| `sender_email` | string | Account email | E.123 |
| `sender_phone` | string | Account phone (digits only) | E.123 |
| `sender_country_code` | string | Country | ISO 3166-1 alpha-2 |
| `sender_create_date` | string | Account creation date | One of the accepted ISO formats: `yyyy-mm-ddThh:mm:ss.000-00:00`, `yyyy-mm-ddThh:mm:ssZ`, `yyyy-mm-dd`, `yyyymmdd` |
| `highrisk_txn_flag` | number | High-risk item flag | `0` normal, `1` high-risk (gift cards, cash equivalents) |
| `vertical` | string | Industry vertical | `Retail`, `Travel`, etc. Confirm valid set with PayPal Integration Engineer |
| `cd_string_one` | string | Trust level | `"1"` trusted, `"0"` unknown/guest, `"2"` blacklisted |

> **Industry pack:** the keys above are the generic retail set. Travel, Gaming, Financial Services, etc. have additional keys. Ask your Integration Engineer for the relevant pack.

### Server proxy implementation

```js
app.post('/api/stc/:cmid', async (req, res) => {
  try {
    const { cmid } = req.params;
    const buyer    = await getAuthenticatedUserContext(req); // from your session

    const { access_token } = await generateAccessToken();
    const url = `${process.env.PAYPAL_API_BASE}/v1/risk/transaction-contexts/${process.env.PAYPAL_MERCHANT_ID}/${cmid}`;

    const body = {
      additional_data: [
        { key: 'sender_account_id',   value: buyer.id },
        { key: 'sender_first_name',   value: buyer.firstName },
        { key: 'sender_last_name',    value: buyer.lastName },
        { key: 'sender_email',        value: buyer.email },
        { key: 'sender_phone',        value: buyer.phoneDigits },
        { key: 'sender_country_code', value: buyer.countryCode }, // ISO 3166-1 alpha-2
        { key: 'sender_create_date',  value: buyer.createdAtIso },
        { key: 'highrisk_txn_flag',   value: req.body.highRisk ? 1 : 0 },
        { key: 'vertical',            value: process.env.MERCHANT_VERTICAL || 'Retail' },
        { key: 'cd_string_one',       value: classifyTrustLevel(buyer) }, // "0" | "1" | "2"
      ],
    };

    const r = await fetch(url, {
      method:  'PUT',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify(body),
    });

    // Non-blocking: always 200 to the browser, log failures internally
    if (!r.ok) {
      const detail = await r.text();
      console.warn(`[STC] ${r.status}`, detail);
      return res.status(200).json({ success: false, stcStatus: r.status });
    }
    res.status(200).json({ success: true });
  } catch (err) {
    console.error('[STC] network error', err.message);
    res.status(200).json({ success: false, error: err.message });
  }
});
```

### Frontend invocation

```js
async function callSTC(cmid) {
  try { await fetch(`/api/stc/${cmid}`, { method: 'POST' }); }
  catch (err) { console.warn('STC failed (non-blocking):', err); }
}
```

Call `callSTC(cmid)` immediately before each Create Order — for both new-card and saved-card flows. Don't await it sequentially in a way that blocks `cardField.submit()`; fire it in parallel or just before.

### Response codes

| HTTP | Meaning | Action |
|------|---------|--------|
| 200 | Success | Continue |
| 400 | Invalid request | Log, continue (check `additional_data` shape, especially date format) |
| 401 | Unauthorized | Log, continue (check MERCHANT_ID and access_token) |
| 500 | PayPal internal | Log, continue |

## How the CMID flows from browser to PayPal headers

```
1. Browser generates cmid (once per session)
2. Browser puts cmid in:
   - Fraudnet config "f"
   - SDK <script data-client-metadata-id="cmid">
3. Browser → POST /api/stc/{cmid}                    (server uses cmid in URL)
4. Browser → POST /api/orders body { ..., _cmid }    (server reads _cmid, removes it from PayPal payload)
5. Server   → POST /v2/checkout/orders               (header PayPal-Client-Metadata-Id: cmid)
6. Browser → POST /api/orders/{id}/capture body { _cmid }
7. Server   → POST /v2/checkout/orders/{id}/capture  (same header)
```

The underscore prefix on `_cmid` is a convention indicating "internal control field, not part of the PayPal payload." The server strips it before forwarding.

## Pitfalls

| Pitfall | Why | Fix |
|---------|-----|-----|
| Different CMIDs across Fraudnet / STC / order | Generated more than once | Generate exactly once per session and reuse. |
| `PayPal-Client-Metadata-Id` missing on capture | Only added to Create Order | Inject it on Capture too — Fraudnet correlates both events. |
| STC blocks the checkout on error | Treated as fatal | STC is non-blocking. Always respond 200 to the browser; log failures. |
| `sender_create_date` rejected as 400 | Wrong format | Use one of the accepted ISO 8601 formats listed above. |
| `highrisk_txn_flag` sent as string | Type mismatch | Send as a number (`0` or `1`). |
| Fraudnet loads on every retry | Bug in single-load gate | Use a boolean flag and never reset it within a session. |
| CSP blocks `fb.js` | Default CSP excludes `c.paypal.com` | Add `c.paypal.com` to `script-src`. |
