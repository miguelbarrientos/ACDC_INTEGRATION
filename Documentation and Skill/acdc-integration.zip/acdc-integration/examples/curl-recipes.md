# cURL Recipes for ACDC

Use these against your **own** server proxy (`/api/...`) or directly against PayPal's REST APIs (when running server-side smoke tests). All sensitive values come from environment variables — never paste real credentials or card numbers into shell history.

```bash
# Set these in your shell session (or read from .env)
export PAYPAL_API_BASE="https://api-m.sandbox.paypal.com"
export PAYPAL_CLIENT_ID="..."
export PAYPAL_CLIENT_SECRET="..."
export PAYPAL_MERCHANT_ID="..."
export CMID="$(uuidgen | tr -d '-' | tr 'A-Z' 'a-z')"
```

---

## 1. OAuth2 token (server-side smoke test)

```bash
CREDS=$(printf '%s' "$PAYPAL_CLIENT_ID:$PAYPAL_CLIENT_SECRET" | base64)

curl -s -X POST "$PAYPAL_API_BASE/v1/oauth2/token" \
  -H "Authorization: Basic $CREDS" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&response_type=id_token" | jq .
```

Expected: `{"access_token": "...", "id_token": "...", "expires_in": ..., "token_type": "Bearer"}`.

```bash
export ACCESS_TOKEN="..."
```

---

## 2. Create Order (against PayPal directly)

> Replace placeholders. Build the body server-side from your real cart.

```bash
curl -s -X POST "$PAYPAL_API_BASE/v2/checkout/orders" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -H "PayPal-Request-Id: $(uuidgen)" \
  -H "PayPal-Client-Metadata-Id: $CMID" \
  -d @- <<'JSON' | jq .
{
  "intent": "CAPTURE",
  "purchase_units": [{
    "invoice_id":  "INV-PLACEHOLDER",
    "custom_id":   "ORDER-PLACEHOLDER",
    "description": "Reference order for smoke test",
    "amount": {
      "currency_code": "MXN",
      "value": "100.00",
      "breakdown": {
        "item_total": { "currency_code": "MXN", "value": "100.00" },
        "tax_total":  { "currency_code": "MXN", "value": "0.00"   },
        "shipping":   { "currency_code": "MXN", "value": "0.00"   },
        "discount":   { "currency_code": "MXN", "value": "0.00"   }
      }
    },
    "items": [{
      "name": "Reference Item",
      "sku":  "REF-001",
      "quantity": "1",
      "unit_amount": { "currency_code": "MXN", "value": "100.00" },
      "tax":         { "currency_code": "MXN", "value": "0.00"   },
      "category": "PHYSICAL_GOODS"
    }]
  }]
}
JSON
```

Capture the `id` from the response: `export ORDER_ID="..."`.

---

## 3. Get Order

```bash
curl -s "$PAYPAL_API_BASE/v2/checkout/orders/$ORDER_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" | jq .
```

If `status == "COMPLETED"`, capture already happened (typical with `payment_source.token`). Otherwise expect `CREATED` or `APPROVED`.

---

## 4. Capture Order

```bash
curl -s -X POST "$PAYPAL_API_BASE/v2/checkout/orders/$ORDER_ID/capture" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -H "PayPal-Client-Metadata-Id: $CMID" \
  -d '{}' | jq .
```

---

## 5. List Vault tokens

```bash
export INTERNAL_USER_ID="user_123"

curl -s "$PAYPAL_API_BASE/v3/vault/payment-tokens?customer_id=$INTERNAL_USER_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" | jq '.payment_tokens[] | {id, brand: .payment_source.card.brand, last4: .payment_source.card.last_digits}'
```

---

## 6. Delete a Vault token

```bash
export TOKEN_ID="..."

curl -s -X DELETE "$PAYPAL_API_BASE/v3/vault/payment-tokens/$TOKEN_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" -i
```

`HTTP/1.1 204 No Content` on success.

---

## 7. Calculated financing options for a saved token

```bash
curl -s -X POST "$PAYPAL_API_BASE/v1/credit/calculated-financing-options" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @- <<JSON | jq '.financing_options[] | select(.product=="CARD_ISSUER_INSTALLMENTS") | .qualifying_financing_options[] | {term: .credit_financing.term, fee: .total_consumer_fee.value, ref: .fee_reference_id}'
{
  "financing_country_code": "MX",
  "flow_context": { "attributes": ["FEE_POLICY_CHARGE_CONSUMER"] },
  "transaction_amount": { "value": "1000.00", "currency_code": "MXN" },
  "funding_instrument": {
    "type": "TOKEN",
    "token": { "type": "PAYMENT_METHOD_TOKEN", "payment_method_token": "$TOKEN_ID" }
  }
}
JSON
```

---

## 8. STC — Set Transaction Context

```bash
curl -s -X PUT "$PAYPAL_API_BASE/v1/risk/transaction-contexts/$PAYPAL_MERCHANT_ID/$CMID" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @- <<'JSON' | jq .
{
  "additional_data": [
    { "key": "sender_account_id",   "value": "USER_ID_PLACEHOLDER" },
    { "key": "sender_first_name",   "value": "FIRST_NAME_PLACEHOLDER" },
    { "key": "sender_last_name",    "value": "LAST_NAME_PLACEHOLDER" },
    { "key": "sender_email",        "value": "buyer@example.com" },
    { "key": "sender_phone",        "value": "5512345678" },
    { "key": "sender_country_code", "value": "MX" },
    { "key": "sender_create_date",  "value": "2024-08-01T12:00:00Z" },
    { "key": "highrisk_txn_flag",   "value": 0 },
    { "key": "vertical",            "value": "Retail" },
    { "key": "cd_string_one",       "value": "1" }
  ]
}
JSON
```

Expected: `200`. Treat any error as non-blocking.

---

## 9. Calling your own server (after wiring `/api/*`)

```bash
# Token endpoint that the browser uses
curl -s http://localhost:3000/api/token | jq .

# Create order via your proxy (browser sends this; server adds the headers)
curl -s -X POST http://localhost:3000/api/orders \
  -H "Content-Type: application/json" \
  -d '{ "_cmid": "'"$CMID"'" }' | jq .

# Capture
curl -s -X POST "http://localhost:3000/api/orders/$ORDER_ID/capture" \
  -H "Content-Type: application/json" \
  -d '{ "_cmid": "'"$CMID"'" }' | jq .
```
