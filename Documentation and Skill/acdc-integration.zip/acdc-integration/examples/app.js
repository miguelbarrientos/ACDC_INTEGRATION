/**
 * ACDC Reference Frontend (vanilla JS)
 * -------------------------------------
 * Generic, sanitized reference for a PayPal Advanced Credit and Debit Card
 * checkout. NO HARDCODED CARD DATA. NO HARDCODED SECRETS. The cart, buyer,
 * and merchant identity come from the server side via /api/* endpoints.
 *
 * Flow on page load:
 *   1) Generate CMID once
 *   2) Load Fraudnet once
 *   3) GET /api/token → clientId + idToken
 *   4) Append the PayPal SDK <script> with data-sdk-client-token and
 *      data-client-metadata-id
 *   5) Render Card Fields and (optionally) saved-card list
 *
 * Replace stubs marked TODO with real calls into your application state.
 */

(() => {
  // ------------------------------------------------------------
  //  Session-scoped state
  // ------------------------------------------------------------
  let cmid           = null;     // generated once per checkout session
  let fraudnetLoaded = false;
  let cardField      = null;     // the paypal.CardFields instance
  let installmentOptions = [];   // last loaded financing options for label/data lookup
  let selectedSavedTokenId = null; // null if buyer is paying with a new card

  // ------------------------------------------------------------
  //  CMID — generate once, reuse everywhere
  // ------------------------------------------------------------
  function generateCMID() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID().replace(/-/g, '');
    }
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }

  // ------------------------------------------------------------
  //  Fraudnet — config script + library, ONE TIME ONLY
  // ------------------------------------------------------------
  async function loadFraudnet(cmidValue) {
    if (fraudnetLoaded) return;
    fraudnetLoaded = true;

    // The merchant short name and PayPal merchant id come from a server-rendered
    // configuration. Never hardcode these in the frontend bundle.
    const cfg = await fetch('/api/public-config').then(r => r.json());
    // cfg = { merchantShortName: 'YOUR_BRAND', paypalMerchantId: '...' }

    const configScript = document.createElement('script');
    configScript.type = 'application/json';
    configScript.setAttribute('fncls', 'fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99');
    configScript.textContent = JSON.stringify({
      f: cmidValue,
      s: `${cfg.merchantShortName}_${cfg.paypalMerchantId}_ACDC`,
    });
    document.body.appendChild(configScript);

    const libScript = document.createElement('script');
    libScript.type = 'text/javascript';
    libScript.src  = 'https://c.paypal.com/da/r/fb.js';
    document.body.appendChild(libScript);
  }

  // ------------------------------------------------------------
  //  STC — fire-and-forget before each Create Order
  // ------------------------------------------------------------
  function callSTC(cmidValue) {
    return fetch(`/api/stc/${encodeURIComponent(cmidValue)}`, { method: 'POST' })
      .catch(err => console.warn('STC failed (non-blocking):', err));
  }

  // ------------------------------------------------------------
  //  Cart helpers
  //
  //  In production these read from server-controlled state, not the DOM.
  // ------------------------------------------------------------
  async function getCartSnapshot() {
    // TODO: replace with your real cart-fetch endpoint
    const r = await fetch('/api/cart');
    if (!r.ok) throw new Error('Could not load cart');
    return r.json();
  }

  // ------------------------------------------------------------
  //  Saved cards (Vault) — list, select, charge
  // ------------------------------------------------------------
  async function renderSavedCards() {
    const cfg = await fetch('/api/public-config').then(r => r.json());
    if (!cfg.userId) return; // not logged in

    const r = await fetch(`/api/vault/payment-tokens?customer_id=${encodeURIComponent(cfg.userId)}`);
    if (!r.ok) return;
    const data   = await r.json();
    const tokens = data.payment_tokens || [];
    if (tokens.length === 0) return;

    const list  = document.querySelector('#saved-cards-list');
    list.innerHTML = '';
    tokens.forEach(t => {
      const card = t.payment_source?.card;
      if (!card) return;
      const li = document.createElement('li');
      li.innerHTML = `
        <label>
          <input type="radio" name="saved-card" value="${t.id}" />
          <strong>${card.brand}</strong> ****${card.last_digits}
          <span class="exp">(exp. ${card.expiry || '—'})</span>
        </label>
        <button class="delete-token" type="button" data-token="${t.id}" aria-label="Eliminar tarjeta">Eliminar</button>
      `;
      list.appendChild(li);
    });
    document.querySelector('#saved-cards-section').hidden = false;

    list.addEventListener('change', async (e) => {
      if (e.target.name !== 'saved-card') return;
      selectedSavedTokenId = e.target.value;
      const cart = await getCartSnapshot();
      await loadInstallmentsForToken(selectedSavedTokenId, cart.totals.total.toFixed(2), cart.currency);
    });

    list.addEventListener('click', async (e) => {
      const btn = e.target.closest('.delete-token');
      if (!btn) return;
      const tokenId = btn.dataset.token;
      const del = await fetch(`/api/vault/payment-tokens/${encodeURIComponent(tokenId)}`, { method: 'DELETE' });
      if (del.status === 204) await renderSavedCards();
    });
  }

  async function loadInstallmentsForToken(tokenId, amount, currency) {
    const r = await fetch('/api/credit/financing-options', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ tokenId, amount, currencyCode: currency }),
    });
    const data = r.ok ? await r.json() : { financing_options: [] };
    populateMonthsSelect(data.financing_options || []);
  }

  // ------------------------------------------------------------
  //  Installments — shared renderer for new card and saved card
  // ------------------------------------------------------------
  function populateMonthsSelect(financingOptions) {
    installmentOptions = financingOptions
      .filter(opt => opt.product === 'CARD_ISSUER_INSTALLMENTS')
      .flatMap(opt => opt.qualifying_financing_options);

    const select = document.querySelector('#installments-select');
    select.innerHTML = '<option value="">1 pago</option>';

    installmentOptions.forEach((opt, i) => {
      const isMSI = parseFloat(opt.total_consumer_fee.value) === 0;
      const label = isMSI
        ? `${opt.credit_financing.term} meses sin intereses`
        : `${opt.credit_financing.term} meses — cargo $${opt.total_consumer_fee.value} ${opt.total_consumer_fee.currency_code}`;
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = label;
      select.appendChild(o);
    });
  }

  function readSelectedInstallment() {
    const select = document.querySelector('#installments-select');
    const idx    = select.value;
    if (idx === '' || idx == null) return null;
    const opt = installmentOptions[Number(idx)];
    if (!opt) return null;
    return {
      term:             opt.credit_financing.term,
      intervalDuration: opt.credit_financing.interval_duration, // SDK uses camelCase
      feeReferenceId:   opt.fee_reference_id || '',
    };
  }

  // ------------------------------------------------------------
  //  Card Fields rendering (new-card flow)
  // ------------------------------------------------------------
  function renderCardFields() {
    if (!window.paypal || !paypal.CardFields) {
      throw new Error('PayPal SDK not loaded');
    }

    cardField = paypal.CardFields({
      style: {
        input:      { 'font-size': '16px', 'font-family': 'system-ui, sans-serif' },
        '.invalid': { color: '#d8000c' },
        ':focus':   { color: '#0070ba' },
      },

      createOrder: async () => {
        const cart = await getCartSnapshot();

        // STC right before Create Order — fire and forget
        callSTC(cmid);

        const body = {
          // Server builds the actual payload; we just send control fields.
          _cmid: cmid,
          // If the buyer picked a saved card via the radio list, use that flow.
          savedTokenId: selectedSavedTokenId || undefined,
          installments: readSelectedInstallment() || undefined,
          saveCardForFuture: !!document.querySelector('#vault')?.checked,
          // The cart (amounts, items, shipping) is read on the server from your
          // session/database — never from the browser body.
        };

        const r    = await fetch('/api/orders', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify(body),
        });
        const data = await r.json();
        if (!r.ok) throw new Error(`createOrder ${r.status}: ${JSON.stringify(data)}`);
        return data.id;
      },

      onApprove: async (data) => {
        // 3DS Risk Initiated decision
        if (data.liabilityShift && data.liabilityShift !== 'POSSIBLE') {
          showError('La autenticación 3DS no se completó. Intenta con otra tarjeta o método.');
          return;
        }
        await captureOrder(data.orderID);
      },

      onError: (err) => {
        console.error('CardFields onError:', err);
        showError('Ocurrió un error procesando el pago. Intenta de nuevo.');
      },

      installments: {
        onInstallmentsRequested: async () => {
          const cart = await getCartSnapshot();
          return {
            financing_country_code: 'MX',
            transaction_amount: { value: cart.totals.total.toFixed(2), currency_code: cart.currency },
            billing_address:    { country_code: 'MX' },
            includeBuyerInstallments: true,
          };
        },
        onInstallmentsAvailable: ({ financing_options }) => {
          populateMonthsSelect(financing_options || []);
        },
      },
    });

    if (!cardField.isEligible()) {
      // Fallback: show PayPal Buttons or a clear "card unavailable" message.
      document.querySelector('#new-card-section').innerHTML =
        '<p>Pago con tarjeta no disponible en este contexto. Usa PayPal.</p>';
      return;
    }

    cardField.NumberField().render('#card-number-field-container');
    cardField.ExpiryField().render('#card-expiry-field-container');
    cardField.CVVField().render('#card-cvv-field-container');
    cardField.NameField().render('#card-name-field-container');

    document.querySelector('#card-field-submit').addEventListener('click', async () => {
      // Saved-card flow: skip cardField.submit() and go straight to Create Order
      if (selectedSavedTokenId) {
        try {
          callSTC(cmid);
          const r = await fetch('/api/orders', {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
              _cmid: cmid,
              savedTokenId: selectedSavedTokenId,
              installments: readSelectedInstallment() || undefined,
            }),
          });
          const order = await r.json();
          if (!r.ok) throw new Error(`createOrder ${r.status}: ${JSON.stringify(order)}`);

          // Token flows often auto-capture; check status first.
          const status = await fetch(`/api/orders/${encodeURIComponent(order.id)}`).then(s => s.json());
          if (status.status === 'COMPLETED') {
            showSuccess(status);
          } else {
            await captureOrder(order.id);
          }
        } catch (err) {
          showError(err.message || 'Error procesando el pago');
        }
        return;
      }

      // New-card flow: hand over to the SDK
      const installments = readSelectedInstallment();
      const submitArgs   = installments && installments.term > 1 ? { installments } : {};
      try {
        await cardField.submit(submitArgs);
        // onApprove fires on success.
      } catch (err) {
        showError(extractFriendlyMessage(err));
      }
    });
  }

  async function captureOrder(orderId) {
    const r = await fetch(`/api/orders/${encodeURIComponent(orderId)}/capture`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ _cmid: cmid }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(`capture ${r.status}: ${JSON.stringify(data)}`);
    showSuccess(data);
  }

  function showSuccess(result) {
    const captureId = result?.purchase_units?.[0]?.payments?.captures?.[0]?.id;
    document.querySelector('#payment-result').textContent =
      `Pago aprobado. Referencia: ${captureId || result.id}`;
    document.querySelector('#card-error').textContent = '';
  }

  function showError(message) {
    document.querySelector('#card-error').textContent = message;
  }

  function extractFriendlyMessage(err) {
    // Map PayPal-side codes to friendly copy. Never show stack traces or PANs.
    if (!err) return 'Error desconocido';
    if (err.message?.includes('INSTRUMENT_DECLINED')) return 'Tu tarjeta fue rechazada. Intenta con otra.';
    if (err.message?.includes('PAYER_ACTION_REQUIRED')) return 'Es necesaria una acción de autenticación adicional.';
    return 'No pudimos completar el pago. Intenta de nuevo.';
  }

  // ------------------------------------------------------------
  //  PayPal SDK loader
  // ------------------------------------------------------------
  function loadPayPalSdk({ clientId, idToken, cmidValue }) {
    return new Promise((resolve, reject) => {
      const url = new URL('https://www.paypal.com/sdk/js');
      url.searchParams.set('client-id',  clientId);
      url.searchParams.set('components', 'buttons,card-fields');
      url.searchParams.set('currency',   'MXN');
      url.searchParams.set('locale',     'es_MX');

      const s = document.createElement('script');
      s.src = url.toString();
      s.setAttribute('data-sdk-client-token',   idToken);
      s.setAttribute('data-client-metadata-id', cmidValue);
      s.onload  = () => resolve();
      s.onerror = () => reject(new Error('Failed to load PayPal SDK'));
      document.body.appendChild(s);
    });
  }

  // ------------------------------------------------------------
  //  Bootstrap
  // ------------------------------------------------------------
  async function bootstrap() {
    try {
      cmid = generateCMID();
      await loadFraudnet(cmid);

      const { clientId, idToken } = await fetch('/api/token').then(r => r.json());
      await loadPayPalSdk({ clientId, idToken, cmidValue: cmid });

      renderCardFields();
      renderSavedCards();
    } catch (err) {
      console.error('Bootstrap failed:', err);
      showError('No pudimos iniciar el checkout. Recarga la página o contacta soporte.');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }
})();
