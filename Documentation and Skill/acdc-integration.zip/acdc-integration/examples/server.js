/**
 * ACDC Reference Server (Node.js / Express)
 * ------------------------------------------
 * Generic, sanitized reference for a PayPal Advanced Credit and Debit Card
 * integration. NO HARDCODED CARD DATA. NO HARDCODED CREDENTIALS.
 * All sensitive values come from environment variables or the authenticated
 * user session.
 *
 * Required env vars (set in .env, not committed):
 *   PAYPAL_API_BASE        e.g. https://api-m.sandbox.paypal.com or https://api-m.paypal.com
 *   PAYPAL_CLIENT_ID       From your PayPal Developer dashboard
 *   PAYPAL_CLIENT_SECRET   From your PayPal Developer dashboard (server only!)
 *   PAYPAL_MERCHANT_ID     Required for STC
 *   MERCHANT_SHORT_NAME    Used in Fraudnet "s" field (your brand short code)
 *   MERCHANT_VERTICAL      e.g. "Retail", "Travel"
 *   PORT                   Default 3000
 */

require('dotenv').config();
const express        = require('express');
const cors           = require('cors');
const fetch          = require('node-fetch');         // or use built-in fetch on Node 18+
const { randomUUID } = require('crypto');
const path           = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ------------------------------------------------------------
//  Required environment validation — fail fast at boot
// ------------------------------------------------------------
const REQUIRED_ENV = [
  'PAYPAL_API_BASE',
  'PAYPAL_CLIENT_ID',
  'PAYPAL_CLIENT_SECRET',
  'PAYPAL_MERCHANT_ID',
];
for (const k of REQUIRED_ENV) {
  if (!process.env[k]) {
    console.error(`Missing required env var: ${k}`);
    process.exit(1);
  }
}

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// ------------------------------------------------------------
//  OAuth2 token cache (with concurrent-call safety)
// ------------------------------------------------------------
const TOKEN_EXPIRY_BUFFER_MS = 60 * 1000;
const oauthCache = { accessToken: null, idToken: null, expiresAt: 0, pending: null };

async function generateAccessToken() {
  const now = Date.now();
  if (oauthCache.accessToken && oauthCache.expiresAt > now) {
    return { access_token: oauthCache.accessToken, id_token: oauthCache.idToken };
  }
  if (oauthCache.pending) return oauthCache.pending;

  oauthCache.pending = (async () => {
    const credentials = Buffer.from(
      `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
    ).toString('base64');

    const r = await fetch(`${process.env.PAYPAL_API_BASE}/v1/oauth2/token`, {
      method:  'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type':  'application/x-www-form-urlencoded',
      },
      body: 'grant_type=client_credentials&response_type=id_token',
    });

    if (!r.ok) throw new Error(`OAuth2 ${r.status}: ${await r.text()}`);
    const data  = await r.json();
    const ttlMs = Number(data.expires_in || 0) * 1000;

    oauthCache.accessToken = data.access_token;
    oauthCache.idToken     = data.id_token;
    oauthCache.expiresAt   = Date.now() + Math.max(ttlMs - TOKEN_EXPIRY_BUFFER_MS, 0);

    return { access_token: data.access_token, id_token: data.id_token };
  })();

  try   { return await oauthCache.pending; }
  finally { oauthCache.pending = null; }
}

// ------------------------------------------------------------
//  Cart resolver (placeholder — replace with your real source of truth)
// ------------------------------------------------------------
async function getCartForRequest(req) {
  // TODO: read the cart from your database / session, not from the browser body.
  // The shape returned here must drive purchase_units in /api/orders.
  // Example:
  //   const cart = await db.carts.findOne({ userId: req.session.user.id });
  //   return cart;
  throw new Error('Implement getCartForRequest() against your real cart store');
}

// ------------------------------------------------------------
//  Build a Create Order payload from the cart and buyer
// ------------------------------------------------------------
function buildOrderPayload({ cart, buyer, savedTokenId, installments }) {
  const payload = {
    intent: 'CAPTURE',
    application_context: {
      brand_name:          process.env.MERCHANT_BRAND_NAME || 'Your Brand',
      locale:              'es-MX',
      shipping_preference: 'SET_PROVIDED_ADDRESS',
      user_action:         'PAY_NOW',
      return_url:          process.env.MERCHANT_RETURN_URL,
      cancel_url:          process.env.MERCHANT_CANCEL_URL,
    },
    payer: {
      email_address: buyer.email,
      name: { given_name: buyer.firstName, surname: buyer.lastName },
      phone: {
        phone_type:  'MOBILE',
        phone_number: { national_number: buyer.phoneDigits },
      },
    },
    purchase_units: [{
      invoice_id:  cart.invoiceId,
      custom_id:   cart.internalOrderId,
      description: cart.description,
      amount: {
        currency_code: cart.currency,
        value:         cart.totals.total.toFixed(2),
        breakdown: {
          item_total: { currency_code: cart.currency, value: cart.totals.itemTotal.toFixed(2) },
          tax_total:  { currency_code: cart.currency, value: cart.totals.taxTotal.toFixed(2)  },
          shipping:   { currency_code: cart.currency, value: cart.totals.shipping.toFixed(2)  },
          discount:   { currency_code: cart.currency, value: cart.totals.discount.toFixed(2)  },
        },
      },
      items: cart.items.map(it => ({
        name:        it.name,
        description: it.description,
        sku:         it.sku,
        quantity:    String(it.quantity),
        unit_amount: { currency_code: cart.currency, value: it.unitPrice.toFixed(2) },
        tax:         { currency_code: cart.currency, value: it.unitTax.toFixed(2)   },
        category:    it.category || 'PHYSICAL_GOODS',
      })),
      shipping: {
        name: { full_name: cart.shipping.fullName },
        address: {
          address_line_1: cart.shipping.line1,
          address_line_2: cart.shipping.line2 || '',
          admin_area_2:   cart.shipping.city,
          admin_area_1:   cart.shipping.state,
          postal_code:    cart.shipping.postal,
          country_code:   cart.shipping.countryCode, // ISO 3166-1 alpha-2
        },
      },
    }],
  };

  // Saved-card flow (vault token)
  if (savedTokenId) {
    payload.payment_source = {
      token: {
        id:   savedTokenId,
        type: 'PAYMENT_METHOD_TOKEN',
        ...(installments && installments.term > 1 && {
          attributes: {
            installments: {
              term:              installments.term,
              interval_duration: installments.intervalDuration, // REST: snake_case
              fee_reference_id:  installments.feeReferenceId,
            },
          },
        }),
      },
    };
    return payload;
  }

  // New-card with optional Vault opt-in (vault-with-purchase)
  if (cart.saveCardForFuture) {
    payload.payment_source = {
      card: {
        attributes: {
          customer: { id: buyer.id },
          vault: {
            store_in_vault:                 'ON_SUCCESS',
            usage_type:                     'MERCHANT',
            customer_type:                  'CONSUMER',
            permit_multiple_payment_tokens: true,
          },
        },
      },
    };
  }
  return payload;
}

// ------------------------------------------------------------
//  /api/token — public client_id + short-lived id_token for the SDK
// ------------------------------------------------------------
app.get('/api/token', async (_req, res) => {
  try {
    const { id_token } = await generateAccessToken();
    res.json({ clientId: process.env.PAYPAL_CLIENT_ID, idToken: id_token });
  } catch (err) {
    console.error('[/api/token]', err.message);
    res.status(500).json({ error: 'Could not obtain token' });
  }
});

// ------------------------------------------------------------
//  /api/orders — Create Order
// ------------------------------------------------------------
app.post('/api/orders', async (req, res) => {
  try {
    const { _cmid, savedTokenId, installments } = req.body || {};
    const cart  = await getCartForRequest(req);
    const buyer = await getAuthenticatedBuyer(req); // implement against your session

    const payload   = buildOrderPayload({ cart, buyer, savedTokenId, installments });
    const requestId = randomUUID();

    const { access_token } = await generateAccessToken();
    const headers = {
      'Authorization':     `Bearer ${access_token}`,
      'Content-Type':      'application/json',
      'PayPal-Request-Id': requestId,
    };
    if (_cmid) headers['PayPal-Client-Metadata-Id'] = _cmid;

    const r = await fetch(`${process.env.PAYPAL_API_BASE}/v2/checkout/orders`, {
      method:  'POST',
      headers,
      body:    JSON.stringify(payload),
    });
    const body = await r.json();
    res.status(r.status).json(body);
  } catch (err) {
    console.error('[/api/orders]', err.message);
    res.status(500).json({ error: 'Could not create order' });
  }
});

// ------------------------------------------------------------
//  /api/orders/:id/capture — Capture
// ------------------------------------------------------------
app.post('/api/orders/:orderId/capture', async (req, res) => {
  try {
    const { _cmid }       = req.body || {};
    const { access_token } = await generateAccessToken();

    const headers = {
      'Authorization': `Bearer ${access_token}`,
      'Content-Type':  'application/json',
    };
    if (_cmid) headers['PayPal-Client-Metadata-Id'] = _cmid;

    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v2/checkout/orders/${encodeURIComponent(req.params.orderId)}/capture`,
      { method: 'POST', headers, body: JSON.stringify({}) }
    );
    res.status(r.status).json(await r.json());
  } catch (err) {
    console.error('[/api/orders/:id/capture]', err.message);
    res.status(500).json({ error: 'Could not capture order' });
  }
});

// ------------------------------------------------------------
//  /api/orders/:id — Get Order (used after token-flow Create)
// ------------------------------------------------------------
app.get('/api/orders/:orderId', async (req, res) => {
  try {
    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v2/checkout/orders/${encodeURIComponent(req.params.orderId)}`,
      {
        method:  'GET',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    res.status(r.status).json(await r.json());
  } catch (err) {
    console.error('[/api/orders/:id GET]', err.message);
    res.status(500).json({ error: 'Could not fetch order' });
  }
});

// ------------------------------------------------------------
//  /api/vault/payment-tokens — List
// ------------------------------------------------------------
app.get('/api/vault/payment-tokens', async (req, res) => {
  try {
    const { customer_id } = req.query;
    if (!customer_id) return res.status(400).json({ error: 'customer_id required' });

    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v3/vault/payment-tokens?customer_id=${encodeURIComponent(customer_id)}`,
      {
        method:  'GET',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    res.status(r.status).json(await r.json());
  } catch (err) {
    console.error('[/api/vault/payment-tokens GET]', err.message);
    res.status(500).json({ error: 'Could not list tokens' });
  }
});

// ------------------------------------------------------------
//  /api/vault/payment-tokens/:tokenId — Delete
// ------------------------------------------------------------
app.delete('/api/vault/payment-tokens/:tokenId', async (req, res) => {
  try {
    const { access_token } = await generateAccessToken();
    const r = await fetch(
      `${process.env.PAYPAL_API_BASE}/v3/vault/payment-tokens/${encodeURIComponent(req.params.tokenId)}`,
      {
        method:  'DELETE',
        headers: {
          'Authorization': `Bearer ${access_token}`,
          'Content-Type':  'application/json',
        },
      }
    );
    if (r.status === 204) return res.status(204).send();
    res.status(r.status).json(await r.json());
  } catch (err) {
    console.error('[/api/vault/payment-tokens DELETE]', err.message);
    res.status(500).json({ error: 'Could not delete token' });
  }
});

// ------------------------------------------------------------
//  /api/credit/financing-options — MSI / IC2B for a saved token
// ------------------------------------------------------------
app.post('/api/credit/financing-options', async (req, res) => {
  try {
    const { tokenId, amount, currencyCode } = req.body || {};
    if (!tokenId || !amount || !currencyCode) {
      return res.status(400).json({ error: 'tokenId, amount, currencyCode required' });
    }

    const { access_token } = await generateAccessToken();
    const r = await fetch(`${process.env.PAYPAL_API_BASE}/v1/credit/calculated-financing-options`, {
      method:  'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        financing_country_code: 'MX',
        flow_context:           { attributes: ['FEE_POLICY_CHARGE_CONSUMER'] },
        transaction_amount:     { value: amount, currency_code: currencyCode },
        funding_instrument: {
          type: 'TOKEN',
          token: {
            type: 'PAYMENT_METHOD_TOKEN',
            payment_method_token: tokenId,
          },
        },
      }),
    });
    res.status(r.status).json(await r.json());
  } catch (err) {
    console.error('[/api/credit/financing-options]', err.message);
    res.status(500).json({ error: 'Could not load financing options' });
  }
});

// ------------------------------------------------------------
//  /api/stc/:cmid — Set Transaction Context (non-blocking)
// ------------------------------------------------------------
app.post('/api/stc/:cmid', async (req, res) => {
  try {
    const { cmid } = req.params;
    const buyer    = await getAuthenticatedBuyer(req);
    const { access_token } = await generateAccessToken();

    const url = `${process.env.PAYPAL_API_BASE}/v1/risk/transaction-contexts/${process.env.PAYPAL_MERCHANT_ID}/${cmid}`;
    const body = {
      additional_data: [
        { key: 'sender_account_id',   value: buyer.id },
        { key: 'sender_first_name',   value: buyer.firstName },
        { key: 'sender_last_name',    value: buyer.lastName },
        { key: 'sender_email',        value: buyer.email },
        { key: 'sender_phone',        value: buyer.phoneDigits },
        { key: 'sender_country_code', value: buyer.countryCode },
        { key: 'sender_create_date',  value: buyer.createdAtIso },
        { key: 'highrisk_txn_flag',   value: req.body?.highRisk ? 1 : 0 },
        { key: 'vertical',            value: process.env.MERCHANT_VERTICAL || 'Retail' },
        { key: 'cd_string_one',       value: classifyTrustLevel(buyer) },
      ],
    };

    const r = await fetch(url, {
      method:  'PUT',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify(body),
    });

    // STC is non-blocking — always 200 to the browser
    if (!r.ok) {
      console.warn(`[STC] ${r.status}`, await r.text());
      return res.status(200).json({ success: false, stcStatus: r.status });
    }
    res.status(200).json({ success: true });
  } catch (err) {
    console.error('[STC] network error', err.message);
    res.status(200).json({ success: false, error: err.message });
  }
});

// ------------------------------------------------------------
//  Helpers (replace with real implementations)
// ------------------------------------------------------------
async function getAuthenticatedBuyer(req) {
  // TODO: read from your session/JWT/etc. The values below MUST come from
  // your authenticated user store, not the request body.
  // Example shape:
  // {
  //   id: 'user_42',
  //   firstName: 'Ada', lastName: 'Lovelace',
  //   email: 'ada@example.com',
  //   phoneDigits: '5512345678',
  //   countryCode: 'MX',
  //   createdAtIso: '2024-08-01T12:00:00Z',
  //   trustSignal: 'verified', // optional, used by classifyTrustLevel
  // }
  throw new Error('Implement getAuthenticatedBuyer() against your real auth layer');
}

function classifyTrustLevel(buyer) {
  // "1" trusted, "0" guest/unknown, "2" untrusted/blacklisted
  if (!buyer || !buyer.id)            return '0';
  if (buyer.blacklisted)              return '2';
  if (buyer.lifetimeOrders >= 5)      return '1';
  return '0';
}

// ------------------------------------------------------------
app.listen(PORT, () => {
  console.log(`ACDC reference server listening on http://localhost:${PORT}`);
});
